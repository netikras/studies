




#########################################
##           Create tables             ##
#########################################



-- Created by Vertabelo (http://vertabelo.com)
-- Last modification date: 2015-12-30 13:25:29.033




-- tables
-- Table T_ITirenginiai
CREATE TABLE T_ITirenginiai (
    T_inventorius_C_inv_num varchar(30)  NOT NULL,
    C_pavadinimas varchar(30)  NOT NULL,
    C_IP varchar(15)  NULL,
    C_prievadas int  NULL,
    C_info varchar(256)  NOT NULL,
    C_tipas varchar(20)  NOT NULL,
    CONSTRAINT T_ITirenginiai_pk PRIMARY KEY (T_inventorius_C_inv_num)
) ENGINE = InnoDB ;

-- Table T_antenos
CREATE TABLE T_antenos (
    T_inventorius_C_inv_num varchar(30)  NOT NULL,
    C_koord_N varchar(16)  NOT NULL,
    C_koord_W varchar(16)  NOT NULL,
    C_stiprumas real(6,5)  NOT NULL,
    CONSTRAINT T_antenos_pk PRIMARY KEY (T_inventorius_C_inv_num)
) ENGINE = InnoDB ;

-- Table T_darbuotojai
CREATE TABLE T_darbuotojai (
    C_id varchar(16)  NOT NULL,
    T_padaliniai_C_padalinio_id varchar(16)  NOT NULL,
    C_vardas varchar(32)  NOT NULL,
    C_pavarde varchar(32)  NOT NULL,
    C_pareigos varchar(32)  NOT NULL,
    C_tel_nr varchar(16)  NOT NULL,
    C_el_p varchar(32)  NULL,
    C_gyven_adr varchar(64)  NULL,
    CONSTRAINT T_darbuotojai_pk PRIMARY KEY (C_id)
) ENGINE = InnoDB ;

-- Table T_inventorius
CREATE TABLE T_inventorius (
    C_inv_num varchar(30)  NOT NULL,
    T_tiekeju_sutartys_C_numeris varchar(16)  NOT NULL,
    T_padaliniai_C_padalinio_id varchar(16)  NOT NULL,
    T_darbuotojai_C_id varchar(16)  NOT NULL,
    C_tipas varchar(16)  NOT NULL,
    CONSTRAINT T_inventorius_pk PRIMARY KEY (C_inv_num)
) ENGINE = InnoDB ;

-- Table T_klientu_lizingo_sut
CREATE TABLE T_klientu_lizingo_sut (
    T_klientu_pirkimo_sut_C_numeris varchar(16)  NOT NULL,
    C_im_dydis_eur real(5,2)  NOT NULL,
    C_im_daznis_d int  NOT NULL  DEFAULT 30,
    C_pirma_im datetime  NOT NULL,
    C_paskutine_im datetime  NOT NULL,
    C_atsiskaityta int  NOT NULL  DEFAULT 0,
    CONSTRAINT T_klientu_lizingo_sut_pk PRIMARY KEY (T_klientu_pirkimo_sut_C_numeris)
) ENGINE = InnoDB ;

-- Table T_klientu_paslaugu_sut
CREATE TABLE T_klientu_paslaugu_sut (
    C_numeris varchar(16)  NOT NULL,
    T_darbuotojai_C_id varchar(16)  NOT NULL,
    T_padaliniai_C_padalinio_id varchar(16)  NOT NULL,
    C_pask_imoka datetime  NOT NULL,
    C_pradzia datetime  NOT NULL,
    C_pabaiga datetime  NULL,
    CONSTRAINT T_klientu_paslaugu_sut_pk PRIMARY KEY (C_numeris)
) ENGINE = InnoDB ;

-- Table T_klientu_pirkimo_sut
CREATE TABLE T_klientu_pirkimo_sut (
    C_numeris varchar(16)  NOT NULL,
    T_darbuotojai_C_id varchar(16)  NOT NULL,
    T_prekes_C_inv_num varchar(30)  NOT NULL,
    T_padaliniai_C_padalinio_id varchar(16)  NOT NULL,
    CONSTRAINT T_klientu_pirkimo_sut_pk PRIMARY KEY (C_numeris)
) ENGINE = InnoDB ;

-- Table T_klientu_planai
CREATE TABLE T_klientu_planai (
    T_klientu_paslaugu_sut_C_numeris varchar(16)  NOT NULL,
    T_planai_C_pavadinimas varchar(30)  NOT NULL,
    C_pradzia datetime  NOT NULL,
    C_periodas_d int  NULL  DEFAULT 30,
    CONSTRAINT T_klientu_planai_pk PRIMARY KEY (T_klientu_paslaugu_sut_C_numeris)
) ENGINE = InnoDB ;

-- Table T_padaliniai
CREATE TABLE T_padaliniai (
    C_padalinio_id varchar(16)  NOT NULL,
    C_adresas varchar(30)  NOT NULL,
    C_tipas varchar(20)  NOT NULL  DEFAULT "KAC",
    C_tel_nr varchar(16)  NOT NULL,
    CONSTRAINT T_padaliniai_pk PRIMARY KEY (C_padalinio_id)
) ENGINE = InnoDB ;

-- Table T_planai
CREATE TABLE T_planai (
    C_pavadinimas varchar(30)  NOT NULL,
    C_pradzia datetime  NULL,
    C_pabaiga datetime  NULL,
    C_komentaras varchar(256)  NULL  DEFAULT "Naujas planas",
    CONSTRAINT T_planai_pk PRIMARY KEY (C_pavadinimas)
) ENGINE = InnoDB ;

-- Table T_planu_dovanos
CREATE TABLE T_planu_dovanos (
    T_planai_C_pavadinimas varchar(30)  NOT NULL,
    C_pavadinimas varchar(64)  NOT NULL,
    CONSTRAINT T_planu_dovanos_pk PRIMARY KEY (T_planai_C_pavadinimas,C_pavadinimas)
) ENGINE = InnoDB ;

-- Table T_planu_kainos
CREATE TABLE T_planu_kainos (
    T_planai_C_pavadinimas varchar(30)  NOT NULL,
    C_sms_lt real(2,2)  NULL,
    C_sms_lt_intern real(2,2)  NULL,
    C_skamb_min_lt real(2,2)  NULL,
    C_skamb_min_intern real(2,2)  NULL,
    C_web_mb real(2,2)  NULL,
    CONSTRAINT T_planu_kainos_pk PRIMARY KEY (T_planai_C_pavadinimas)
) ENGINE = InnoDB ;

-- Table T_prekes
CREATE TABLE T_prekes (
    T_inventorius_C_inv_num varchar(30)  NOT NULL,
    C_prekes_pavad varchar(64)  NOT NULL,
    C_prekes_kaina real(5,2)  NOT NULL  DEFAULT 0.00,
    C_prekes_likutis int  NOT NULL  DEFAULT 0,
    C_preke_rodoma int  NOT NULL  DEFAULT 0,
    CONSTRAINT T_prekes_pk PRIMARY KEY (T_inventorius_C_inv_num)
) ENGINE = InnoDB ;

-- Table T_sut_salys
CREATE TABLE T_sut_salys (
    C_sut_nr varchar(16)  NOT NULL,
    C_el_p varchar(30)  NOT NULL,
    C_vardas varchar(30)  NOT NULL,
    C_pavarde varchar(30)  NOT NULL,
    C_tel_nr varchar(16)  NOT NULL,
    C_adresas varchar(50)  NULL,
    CONSTRAINT T_sut_salys_pk PRIMARY KEY (C_sut_nr,C_el_p)
) ENGINE = InnoDB ;

-- Table T_sutartys
CREATE TABLE T_sutartys (
    C_numeris varchar(16)  NOT NULL,
    C_sudarymo_data datetime  NOT NULL,
    C_suma real(7,2)  NOT NULL,
    CONSTRAINT T_sutartys_pk PRIMARY KEY (C_numeris)
) ENGINE = InnoDB ;

-- Table T_tiekeju_sutartys
CREATE TABLE T_tiekeju_sutartys (
    C_numeris varchar(16)  NOT NULL,
    C_numeris_tiekejo varchar(64)  NOT NULL,
    T_darbuotojai_C_id varchar(16)  NOT NULL,
    C_sutarties_objektas varchar(128)  NOT NULL,
    C_galioja_iki datetime  NULL,
    CONSTRAINT T_tiekeju_sutartys_pk PRIMARY KEY (C_numeris)
) ENGINE = InnoDB ;

-- Table T_transportas
CREATE TABLE T_transportas (
    T_inventorius_C_inv_num varchar(30)  NOT NULL,
    C_priemones_tipas varchar(16)  NOT NULL  DEFAULT "WW_Caddy",
    C_valst_nr varchar(16)  NOT NULL,
    CONSTRAINT T_transportas_pk PRIMARY KEY (T_inventorius_C_inv_num)
) ENGINE = InnoDB ;





-- foreign keys
-- Reference:  T_ITirenginiai_T_inventorius (table: T_ITirenginiai)

ALTER TABLE T_ITirenginiai ADD CONSTRAINT T_ITirenginiai_T_inventorius FOREIGN KEY T_ITirenginiai_T_inventorius (T_inventorius_C_inv_num)
    REFERENCES T_inventorius (C_inv_num)
    ON UPDATE CASCADE;
-- Reference:  T_antenos_T_inventorius (table: T_antenos)

ALTER TABLE T_antenos ADD CONSTRAINT T_antenos_T_inventorius FOREIGN KEY T_antenos_T_inventorius (T_inventorius_C_inv_num)
    REFERENCES T_inventorius (C_inv_num)
    ON UPDATE CASCADE;
-- Reference:  T_darbuotojai_T_padaliniai (table: T_darbuotojai)

ALTER TABLE T_darbuotojai ADD CONSTRAINT T_darbuotojai_T_padaliniai FOREIGN KEY T_darbuotojai_T_padaliniai (T_padaliniai_C_padalinio_id)
    REFERENCES T_padaliniai (C_padalinio_id)
    ON DELETE RESTRICT
    ON UPDATE CASCADE;
-- Reference:  T_inventorius_T_darbuotojai (table: T_inventorius)

ALTER TABLE T_inventorius ADD CONSTRAINT T_inventorius_T_darbuotojai FOREIGN KEY T_inventorius_T_darbuotojai (T_darbuotojai_C_id)
    REFERENCES T_darbuotojai (C_id)
    ON DELETE RESTRICT
    ON UPDATE CASCADE;
-- Reference:  T_inventorius_T_padaliniai (table: T_inventorius)

ALTER TABLE T_inventorius ADD CONSTRAINT T_inventorius_T_padaliniai FOREIGN KEY T_inventorius_T_padaliniai (T_padaliniai_C_padalinio_id)
    REFERENCES T_padaliniai (C_padalinio_id)
    ON DELETE RESTRICT
    ON UPDATE CASCADE;
-- Reference:  T_inventorius_T_tiekeju_sutartys (table: T_inventorius)

ALTER TABLE T_inventorius ADD CONSTRAINT T_inventorius_T_tiekeju_sutartys FOREIGN KEY T_inventorius_T_tiekeju_sutartys (T_tiekeju_sutartys_C_numeris)
    REFERENCES T_tiekeju_sutartys (C_numeris)
    ON UPDATE CASCADE;
-- Reference:  T_klientu_lizingo_sut_T_klientu_pirkimo_sut (table: T_klientu_lizingo_sut)

ALTER TABLE T_klientu_lizingo_sut ADD CONSTRAINT T_klientu_lizingo_sut_T_klientu_pirkimo_sut FOREIGN KEY T_klientu_lizingo_sut_T_klientu_pirkimo_sut (T_klientu_pirkimo_sut_C_numeris)
    REFERENCES T_klientu_pirkimo_sut (C_numeris)
    ON DELETE CASCADE
    ON UPDATE RESTRICT;
-- Reference:  T_klientu_paslaugu_sut_T_darbuotojai (table: T_klientu_paslaugu_sut)

ALTER TABLE T_klientu_paslaugu_sut ADD CONSTRAINT T_klientu_paslaugu_sut_T_darbuotojai FOREIGN KEY T_klientu_paslaugu_sut_T_darbuotojai (T_darbuotojai_C_id)
    REFERENCES T_darbuotojai (C_id)
    ON UPDATE CASCADE;
-- Reference:  T_klientu_paslaugu_sut_T_padaliniai (table: T_klientu_paslaugu_sut)

ALTER TABLE T_klientu_paslaugu_sut ADD CONSTRAINT T_klientu_paslaugu_sut_T_padaliniai FOREIGN KEY T_klientu_paslaugu_sut_T_padaliniai (T_padaliniai_C_padalinio_id)
    REFERENCES T_padaliniai (C_padalinio_id)
    ON UPDATE CASCADE;
-- Reference:  T_klientu_paslaugu_sut_T_sutartys (table: T_klientu_paslaugu_sut)

ALTER TABLE T_klientu_paslaugu_sut ADD CONSTRAINT T_klientu_paslaugu_sut_T_sutartys FOREIGN KEY T_klientu_paslaugu_sut_T_sutartys (C_numeris)
    REFERENCES T_sutartys (C_numeris)
    ON DELETE CASCADE
    ON UPDATE RESTRICT;
-- Reference:  T_klientu_pirkimo_sut_T_darbuotojai (table: T_klientu_pirkimo_sut)

ALTER TABLE T_klientu_pirkimo_sut ADD CONSTRAINT T_klientu_pirkimo_sut_T_darbuotojai FOREIGN KEY T_klientu_pirkimo_sut_T_darbuotojai (T_darbuotojai_C_id)
    REFERENCES T_darbuotojai (C_id)
    ON UPDATE CASCADE;
-- Reference:  T_klientu_pirkimo_sut_T_padaliniai (table: T_klientu_pirkimo_sut)

ALTER TABLE T_klientu_pirkimo_sut ADD CONSTRAINT T_klientu_pirkimo_sut_T_padaliniai FOREIGN KEY T_klientu_pirkimo_sut_T_padaliniai (T_padaliniai_C_padalinio_id)
    REFERENCES T_padaliniai (C_padalinio_id)
    ON UPDATE CASCADE;
-- Reference:  T_klientu_pirkimo_sut_T_prekes (table: T_klientu_pirkimo_sut)

ALTER TABLE T_klientu_pirkimo_sut ADD CONSTRAINT T_klientu_pirkimo_sut_T_prekes FOREIGN KEY T_klientu_pirkimo_sut_T_prekes (T_prekes_C_inv_num)
    REFERENCES T_prekes (T_inventorius_C_inv_num)
    ON UPDATE CASCADE;
-- Reference:  T_klientu_pirkimo_sut_T_sutartys (table: T_klientu_pirkimo_sut)

ALTER TABLE T_klientu_pirkimo_sut ADD CONSTRAINT T_klientu_pirkimo_sut_T_sutartys FOREIGN KEY T_klientu_pirkimo_sut_T_sutartys (C_numeris)
    REFERENCES T_sutartys (C_numeris)
    ON DELETE CASCADE
    ON UPDATE RESTRICT;
-- Reference:  T_klientu_planai_T_klientu_paslaugu_sut (table: T_klientu_planai)

ALTER TABLE T_klientu_planai ADD CONSTRAINT T_klientu_planai_T_klientu_paslaugu_sut FOREIGN KEY T_klientu_planai_T_klientu_paslaugu_sut (T_klientu_paslaugu_sut_C_numeris)
    REFERENCES T_klientu_paslaugu_sut (C_numeris)
    ON DELETE CASCADE
    ON UPDATE RESTRICT;
-- Reference:  T_klientu_planai_T_planai (table: T_klientu_planai)

ALTER TABLE T_klientu_planai ADD CONSTRAINT T_klientu_planai_T_planai FOREIGN KEY T_klientu_planai_T_planai (T_planai_C_pavadinimas)
    REFERENCES T_planai (C_pavadinimas)
    ON DELETE CASCADE
    ON UPDATE CASCADE;
-- Reference:  T_planu_dovanos_T_planai (table: T_planu_dovanos)

ALTER TABLE T_planu_dovanos ADD CONSTRAINT T_planu_dovanos_T_planai FOREIGN KEY T_planu_dovanos_T_planai (T_planai_C_pavadinimas)
    REFERENCES T_planai (C_pavadinimas)
    ON DELETE CASCADE
    ON UPDATE CASCADE;
-- Reference:  T_planu_kainos_T_planai (table: T_planu_kainos)

ALTER TABLE T_planu_kainos ADD CONSTRAINT T_planu_kainos_T_planai FOREIGN KEY T_planu_kainos_T_planai (T_planai_C_pavadinimas)
    REFERENCES T_planai (C_pavadinimas)
    ON DELETE RESTRICT
    ON UPDATE CASCADE;
-- Reference:  T_prekes_T_inventorius (table: T_prekes)

ALTER TABLE T_prekes ADD CONSTRAINT T_prekes_T_inventorius FOREIGN KEY T_prekes_T_inventorius (T_inventorius_C_inv_num)
    REFERENCES T_inventorius (C_inv_num)
    ON UPDATE CASCADE;
-- Reference:  T_sut_salys_T_sutartys (table: T_sut_salys)

ALTER TABLE T_sut_salys ADD CONSTRAINT T_sut_salys_T_sutartys FOREIGN KEY T_sut_salys_T_sutartys (C_sut_nr)
    REFERENCES T_sutartys (C_numeris);
-- Reference:  T_tiekeju_sutartys_T_darbuotojai (table: T_tiekeju_sutartys)

ALTER TABLE T_tiekeju_sutartys ADD CONSTRAINT T_tiekeju_sutartys_T_darbuotojai FOREIGN KEY T_tiekeju_sutartys_T_darbuotojai (T_darbuotojai_C_id)
    REFERENCES T_darbuotojai (C_id);
-- Reference:  T_tiekeju_sutartys_T_sutartys (table: T_tiekeju_sutartys)

ALTER TABLE T_tiekeju_sutartys ADD CONSTRAINT T_tiekeju_sutartys_T_sutartys FOREIGN KEY T_tiekeju_sutartys_T_sutartys (C_numeris)
    REFERENCES T_sutartys (C_numeris)
    ON DELETE CASCADE
    ON UPDATE RESTRICT;
-- Reference:  T_transportas_T_inventorius (table: T_transportas)

ALTER TABLE T_transportas ADD CONSTRAINT T_transportas_T_inventorius FOREIGN KEY T_transportas_T_inventorius (T_inventorius_C_inv_num)
    REFERENCES T_inventorius (C_inv_num)
    ON UPDATE CASCADE;



-- End of file.







#########################################
##            Fill tables              ##
#########################################





## T_padaliniai

INSERT INTO `T_padaliniai` (`C_padalinio_id`,`C_adresas`,`C_tipas`,`C_tel_nr`) 
    VALUES 
    ("KIZ57NVW8IB","Ap #763-1279 Aliquam Av.","Research and Development","+37060911545"),
    ("IHP70CXW4CT","399-3263 Non, Avenue","Tech Support","+37065137075"),
    ("MQS01JQW4SN","105-6318 Mauris Rd.","Customer Relations","+37069968051"),
    ("IAX31DKF8US","P.O. Box 817, 8610 Sagittis Avenue","Legal Department","+37066502560"),
    ("CGP66CWN3QO","3698 Amet, Rd.","Tech Support","+37062924503"),
    ("ETP30BZS8PT","Ap #168-6424 Commodo Ave","Advertising","+37062150091"),
    ("QOM84RBK2IO","933-635 Non, Ave","Customer Relations","+37067362576"),
    ("LGR67CSS9EC","234-4021 In Street","Quality Assurance","+37061064376"),
    ("ZWW89SHX8CT","Ap #475-580 Quam, Rd.","Sales and Marketing","+37068001620"),
    ("HKC70SLW3MF","Ap #920-9231 Fusce St.","Customer Service","+37068407529");

INSERT INTO `T_padaliniai` (`C_padalinio_id`,`C_adresas`,`C_tipas`,`C_tel_nr`) 
    VALUES 
    ("NEJ80CDF1KV","3359 Sed St.","Finances","+37061095131"),
    ("GHR82WMZ3JG","Ap #716-4074 Erat St.","Customer Service","+37069753271"),
    ("QVC68AHH0QV","456-6444 Enim. Road","Tech Support","+37065440290"),
    ("ZLR47ZYP6TU","P.O. Box 920, 786 Ligula. Ave","Public Relations","+37067246706"),
    ("CSH94ZZA1FF","P.O. Box 371, 7296 A St.","Research and Development","+37066321933"),
    ("FJO24EQQ8ZE","7183 Lacus. Rd.","Customer Service","+37064621855"),
    ("FQG84NIO6TW","208-7081 Magnis St.","Quality Assurance","+37061582300"),
    ("OEF87CQF9OB","412-4796 Pede, Ave","Public Relations","+37061576117"),
    ("ORH10XAF7IO","730-4230 Fringilla Street","Media Relations","+37063952827"),
    ("RNL66KBW8BT","Ap #748-7515 Lectus Ave","Sales and Marketing","+37064114368");

INSERT INTO `T_padaliniai` (`C_padalinio_id`,`C_adresas`,`C_tipas`,`C_tel_nr`) 
    VALUES 
    ("EGW65RAT9FR","P.O. Box 522, 2168 Sit Av.","Quality Assurance","+37068483555"),
    ("SBE67MUQ6EK","610-8145 Interdum Rd.","Customer Relations","+37063157000"),
    ("PLR27JHY7VR","7333 Cursus St.","Quality Assurance","+37060028085"),
    ("BQS64AHF8YM","Ap #390-2110 A Road","Legal Department","+37062371942"),
    ("QNT88OCF4MW","7043 Orci, Avenue","Research and Development","+37063970622"),
    ("RGR82ONZ3JY","922-9584 Tristique Avenue","Public Relations","+37067245311"),
    ("KVX22OPQ5JV","1961 Parturient Rd.","Asset Management","+37063962896"),
    ("ICR17ENQ2TU","9193 Magna. Avenue","Sales and Marketing","+37061439692"),
    ("PEQ97AKQ2TX","1553 Diam. Ave","Asset Management","+37067258672"),
    ("TMM06FVP8MQ","422-7319 Nam Av.","Accounting","+37066143734");

INSERT INTO `T_padaliniai` (`C_padalinio_id`,`C_adresas`,`C_tipas`,`C_tel_nr`) 
    VALUES 
    ("JIL81VUU1PW","854-4924 Cras Street","Payroll","+37060827548"),
    ("WCQ47CHO9QT","905-4102 Sit Road","Payroll","+37061783756"),
    ("KML09POH7ZB","P.O. Box 677, 9847 Urna Ave","Asset Management","+37062588462"),
    ("RNE55NRS7QZ","Ap #664-8330 Enim, Ave","Sales and Marketing","+37068356953"),
    ("MOP52PWB3HE","327-5882 Metus Av.","Customer Service","+37067371699"),
    ("RIG54WTQ6ZR","992-7074 Gravida Rd.","Quality Assurance","+37066223272"),
    ("TJR37DCX1LX","9537 Tellus Rd.","Research and Development","+37068240894"),
    ("RKU81ZOM2AL","P.O. Box 678, 3472 Eget St.","Tech Support","+37069597091"),
    ("EPT81ZVX8BN","P.O. Box 874, 2204 Lobortis Avenue","Advertising","+37061942540"),
    ("YYV72HTC4JW","4980 Nec, Rd.","Quality Assurance","+37060049353");

INSERT INTO `T_padaliniai` (`C_padalinio_id`,`C_adresas`,`C_tipas`,`C_tel_nr`) 
    VALUES 
    ("ILW09HGY8BS","Ap #628-4198 Consectetuer Ave","Accounting","+37065270440"),
    ("EPF30LTA2VR","1063 Et St.","Human Resources","+37064022196"),
    ("GIW02MWN3SY","3734 Tempus Street","Customer Relations","+37061498252"),
    ("XWH96ELU9DW","P.O. Box 754, 7268 Justo St.","Public Relations","+37067557306"),
    ("YZZ59UOS5XC","8316 Dictum Av.","Tech Support","+37064544314"),
    ("LRG55ZAE5KX","P.O. Box 195, 1068 Orci Avenue","Research and Development","+37067572881"),
    ("JAD31IUN8DS","P.O. Box 170, 4079 Semper Rd.","Accounting","+37068295893"),
    ("YCF68ASP3GV","440-505 Arcu. St.","Media Relations","+37062327626"),
    ("NGQ71LFJ2WO","Ap #888-3702 Tristique Rd.","Quality Assurance","+37061643570"),
    ("AJY33MTZ1YO","Ap #264-2421 Varius Av.","Public Relations","+37069523229");

INSERT INTO `T_padaliniai` (`C_padalinio_id`,`C_adresas`,`C_tipas`,`C_tel_nr`) 
    VALUES 
    ("SKK43RIN4CQ","255-677 Faucibus Rd.","Tech Support","+37064379868"),
    ("QOM21OSR7ZN","Ap #556-1096 Tincidunt Avenue","Public Relations","+37064826451"),
    ("VRE42EEQ8JV","9171 Mi. Rd.","Payroll","+37064453488"),
    ("QSO23SWH8EK","6718 Amet, Ave","Human Resources","+37064409590"),
    ("IKO98RWU0CG","Ap #641-7933 Nec Rd.","Customer Service","+37062989341"),
    ("HWD45SFO2DD","212-5932 At, Av.","Advertising","+37068411154"),
    ("ZZC83BXN0XF","P.O. Box 631, 7013 Adipiscing Av.","Tech Support","+37069023701"),
    ("RPV61OXO0OG","238-297 Interdum Road","Legal Department","+37063849350"),
    ("XWE54YYP8IV","P.O. Box 190, 3612 Integer Road","Tech Support","+37065120834"),
    ("GNN37PVP2ZS","Ap #850-8511 Semper Street","Payroll","+37062565280");

INSERT INTO `T_padaliniai` (`C_padalinio_id`,`C_adresas`,`C_tipas`,`C_tel_nr`) 
    VALUES 
    ("UYG18ZJN9LD","P.O. Box 360, 238 Ut Road","Human Resources","+37063918406"),
    ("HNT42NUP7LN","479-3617 Pede. Avenue","Legal Department","+37060442178"),
    ("HXJ08CMF2LI","211-9313 Lobortis, Rd.","Payroll","+37069195520"),
    ("BTP68ODG0CN","Ap #122-9213 Malesuada Rd.","Media Relations","+37062391871"),
    ("PXA53IVZ9CV","Ap #232-4299 Et, Street","Human Resources","+37069778168"),
    ("GPR82KVK9TW","P.O. Box 455, 1489 Dictum Rd.","Asset Management","+37064907525"),
    ("GNC17KVC7AH","1300 Egestas Rd.","Human Resources","+37062725423"),
    ("FQD90PJT0JO","Ap #996-9817 Metus St.","Finances","+37068488332"),
    ("IQD25GMN9JZ","Ap #632-3678 Blandit Street","Customer Relations","+37069281236"),
    ("HXX73FII0CJ","743-5197 A, Street","Asset Management","+37064000082");

INSERT INTO `T_padaliniai` (`C_padalinio_id`,`C_adresas`,`C_tipas`,`C_tel_nr`) 
    VALUES 
    ("MXQ94MZF5SN","P.O. Box 423, 7886 Velit Av.","Public Relations","+37067548031"),
    ("MLM78CQR3KL","1449 Maecenas Av.","Customer Relations","+37062766299"),
    ("NMM03FZC3OM","P.O. Box 931, 9185 Neque St.","Media Relations","+37067858256"),
    ("ZLC61GYV9CS","Ap #953-9498 Semper Av.","Finances","+37065942145"),
    ("QWV88DGO1HQ","Ap #456-1084 Dapibus Rd.","Sales and Marketing","+37063714759"),
    ("MVG31GID3HK","P.O. Box 226, 6996 Dignissim Ave","Sales and Marketing","+37061823810"),
    ("DIV94LVF3JE","8553 Phasellus Road","Finances","+37065531331"),
    ("KKU08WRW7LE","6263 Mauris, St.","Research and Development","+37066620831"),
    ("NMD15SHW7CP","4234 Donec Rd.","Quality Assurance","+37064395683"),
    ("LAF77LQQ2AD","1372 Lorem Street","Sales and Marketing","+37066758281");

INSERT INTO `T_padaliniai` (`C_padalinio_id`,`C_adresas`,`C_tipas`,`C_tel_nr`) 
    VALUES 
    ("RMH93WYU5HZ","Ap #840-4309 Congue. St.","Advertising","+37067160280"),
    ("DEU13ZZD2EV","P.O. Box 309, 3336 Rutrum St.","Asset Management","+37062456820"),
    ("CSB94WDI8GG","203-7180 In Ave","Legal Department","+37067403413"),
    ("XCK12BRT9BS","8206 Suspendisse Ave","Public Relations","+37064842083"),
    ("YOZ57VDR1NQ","Ap #565-4186 Lectus. Rd.","Sales and Marketing","+37068461557"),
    ("XBA55RQZ8CK","Ap #296-6591 Mauris Street","Customer Service","+37062035889"),
    ("NXA21FZR1DY","P.O. Box 260, 903 Adipiscing Street","Research and Development","+37069679500"),
    ("STS02VJG6QK","Ap #815-2573 Sagittis St.","Customer Relations","+37060539406"),
    ("VAO33LUK1NH","935-2629 Vel, Ave","Public Relations","+37060305251"),
    ("YJO44QTK6RI","P.O. Box 668, 3244 Aliquam Rd.","Accounting","+37064236924");

INSERT INTO `T_padaliniai` (`C_padalinio_id`,`C_adresas`,`C_tipas`,`C_tel_nr`) 
    VALUES 
    ("MDZ32TTP5EZ","P.O. Box 332, 4086 Vestibulum, Street","Quality Assurance","+37065080767"),
    ("DVR10CON8KW","Ap #114-1098 Interdum. St.","Accounting","+37066316075"),
    ("JLL01QAI8KO","9269 Class Road","Human Resources","+37061548862"),
    ("TVB72PEA2VN","Ap #696-1531 Rhoncus. Road","Accounting","+37061407695"),
    ("ILI96COS0CI","114-3671 In Ave","Advertising","+37061391664"),
    ("NWC75KHV5YW","Ap #241-1055 Tellus. Avenue","Human Resources","+37065725610"),
    ("VXM24FPO5RS","4137 Ipsum. St.","Sales and Marketing","+37066473985"),
    ("LDI04VGV5UC","9413 Proin St.","Tech Support","+37063289251"),
    ("UNZ73KVU7IH","Ap #542-9652 Nullam St.","Research and Development","+37066854835"),
    ("VNA32TGI6EA","P.O. Box 674, 8665 Sociosqu Rd.","Media Relations","+37061252615");













## T_darbuotojai

INSERT INTO `T_darbuotojai` (`C_id`,`T_padaliniai_C_padalinio_id`,`C_vardas`,`C_pavarde`,`C_pareigos`,`C_tel_nr`,`C_el_p`,`C_gyven_adr`) 
    VALUES 
    ("B9926201","BTP68ODG0CN","Barclay","Fuentes","Purus Industries","+37064811717","nunc.interdum.feugiat@tortornibhsit.edu","4844 Sit Rd."),
    ("B1593485","CSH94ZZA1FF","Sara","Hobbs","Ipsum Cursus Inc.","+37067563809","eu.lacus.Quisque@antedictum.edu","2247 Tincidunt, Street"),
    ("B3814295","DVR10CON8KW","Kelly","Pace","Sociis Natoque Foundation","+37062245253","magna.nec.quam@Maecenasmalesuadafringilla.co.uk","387-9521 Nibh. St."),
    ("B1727627","EPF30LTA2VR","Jarrod","Aguilar","Luctus Ltd","+37064104563","pede.Praesent@pedeSuspendisse.org","Ap #749-7448 Non Road"),
    ("B0725744","AJY33MTZ1YO","Donovan","Wheeler","Lectus Institute","+37065745401","risus@Fuscefeugiat.com","P.O. Box 735, 3603 Ipsum Avenue"),
    ("B8839135","AJY33MTZ1YO","Regina","Daniels","Risus Morbi Corporation","+37067394926","et.pede.Nunc@Aenean.co.uk","Ap #327-2032 Sociis St."),
    ("B0353604","CSB94WDI8GG","Kiona","Heath","Malesuada Vel Venenatis Industries","+37065911709","velit.eget@anteblandit.org","754-6180 Gravida. Street"),
    ("B4857371","BQS64AHF8YM","Evan","Frazier","Ac Company","+37060331014","et.netus@blandit.ca","P.O. Box 701, 6752 Nam St."),
    ("B3572783","EGW65RAT9FR","Bertha","Wheeler","Justo Sit Amet Inc.","+37064578498","sit@consectetuermaurisid.com","3714 Magnis Avenue"),
    ("B9157977","EGW65RAT9FR","Gisela","Oconnor","Feugiat Metus LLP","+37069315285","Ut.tincidunt@vitaesodalesat.org","Ap #487-8799 Justo St.");

INSERT INTO `T_darbuotojai` (`C_id`,`T_padaliniai_C_padalinio_id`,`C_vardas`,`C_pavarde`,`C_pareigos`,`C_tel_nr`,`C_el_p`,`C_gyven_adr`) 
    VALUES 
    ("B5982162","BQS64AHF8YM","Eugenia","Osborn","Tincidunt Limited","+37067387771","sodales@Crasconvallis.com","780-1548 Turpis. Rd."),
    ("B6520770","EGW65RAT9FR","Carissa","Blackburn","Egestas Corp.","+37066818122","Phasellus.in.felis@sedpede.com","Ap #745-4353 Mauris St."),
    ("B3566002","BTP68ODG0CN","Amery","Buck","Turpis Egestas Aliquam Consulting","+37066222881","dictum.placerat@estvitae.co.uk","6793 Imperdiet Street"),
    ("B1286263","DEU13ZZD2EV","Morgan","Meadows","Nec Enim Nunc Industries","+37062555670","ut.mi@ipsumac.net","731-9777 Egestas Rd."),
    ("B0013156","BQS64AHF8YM","Kaseem","Barnett","Porttitor Consulting","+37060936006","nec@acturpisegestas.com","Ap #110-3067 At, Road"),
    ("B4547434","EGW65RAT9FR","Xyla","Fox","Non Hendrerit Inc.","+37062051893","Mauris.quis@Nullamsuscipitest.co.uk","P.O. Box 504, 2521 Praesent Road"),
    ("B9330168","DVR10CON8KW","Grace","Baldwin","Et Rutrum Eu Incorporated","+37069685803","leo.in.lobortis@dictum.co.uk","Ap #721-4928 Vehicula. Ave"),
    ("B8984167","DVR10CON8KW","Kiayada","Davenport","Dignissim Magna Inc.","+37063932875","ipsum@tellus.com","Ap #914-7046 Dolor Rd."),
    ("B0325529","DEU13ZZD2EV","Brian","Waters","Dapibus Rutrum Justo Foundation","+37069381817","ut@Curabiturvellectus.edu","9608 Nulla St."),
    ("B2450378","EPF30LTA2VR","Jolene","Molina","Fermentum Fermentum Arcu Limited","+37061428185","dapibus.ligula@penatibusetmagnis.ca","Ap #217-6567 Ipsum. Rd.");

INSERT INTO `T_darbuotojai` (`C_id`,`T_padaliniai_C_padalinio_id`,`C_vardas`,`C_pavarde`,`C_pareigos`,`C_tel_nr`,`C_el_p`,`C_gyven_adr`) 
    VALUES 
    ("B1507421","BQS64AHF8YM","Quemby","Hudson","Lobortis Nisi Inc.","+37065245383","Class.aptent.taciti@gravida.org","Ap #965-288 Sed Rd."),
    ("B6417727","AJY33MTZ1YO","Carolyn","Terrell","Magna LLP","+37063788733","sagittis@faucibusMorbivehicula.ca","632-5846 Feugiat. St."),
    ("B3891333","CGP66CWN3QO","Kuame","Haney","Nunc Risus Institute","+37060006654","in@sit.org","Ap #395-5427 Tristique Av."),
    ("B0577052","EPF30LTA2VR","Aiko","Martinez","Nunc Ac Sem Associates","+37069650852","dui.quis.accumsan@augueeu.org","Ap #293-9262 Et Street"),
    ("B2409781","DEU13ZZD2EV","Clio","Moody","Vel Pede Industries","+37061284450","feugiat.Lorem@vestibulum.co.uk","P.O. Box 316, 5805 Et, Street"),
    ("B5603436","CGP66CWN3QO","Priscilla","Burton","Massa Vestibulum Corp.","+37065535998","vitae@blandit.ca","P.O. Box 916, 7304 Sed St."),
    ("B5878151","DEU13ZZD2EV","Evangeline","Morrow","Lobortis Inc.","+37062478816","ridiculus@anteipsumprimis.edu","P.O. Box 430, 3410 Donec St."),
    ("B0063069","BTP68ODG0CN","Maggie","Odonnell","Volutpat Ornare Facilisis Associates","+37063182540","bibendum.fermentum@laoreetposuereenim.ca","288-1708 Vivamus Rd."),
    ("B4493121","BQS64AHF8YM","Ima","Noble","Egestas Sed Incorporated","+37069989812","nonummy@mifringillami.ca","Ap #470-1543 Justo. Avenue"),
    ("B3155255","DEU13ZZD2EV","Trevor","Stephens","Ipsum Institute","+37065660031","sit.amet@duinecurna.edu","784-5061 Vehicula Rd.");

INSERT INTO `T_darbuotojai` (`C_id`,`T_padaliniai_C_padalinio_id`,`C_vardas`,`C_pavarde`,`C_pareigos`,`C_tel_nr`,`C_el_p`,`C_gyven_adr`) 
    VALUES 
    ("B8952892","DVR10CON8KW","Colt","Crawford","Sed Turpis Nec Corp.","+37065816795","In.ornare@Integermollis.co.uk","3552 Non Rd."),
    ("B0743523","DVR10CON8KW","Marah","Zimmerman","Fusce Limited","+37068712878","amet@Donec.net","508-6587 At, Ave"),
    ("B6244412","DIV94LVF3JE","Dara","Weaver","Mauris Molestie Pharetra Consulting","+37063406503","Sed@Intinciduntcongue.edu","6188 Dolor, St."),
    ("B3977718","EGW65RAT9FR","Benjamin","Jackson","Tincidunt Aliquam Arcu Inc.","+37063522568","massa.Vestibulum@ullamcorpereueuismod.co.uk","8193 Curabitur Ave"),
    ("B3407194","EPF30LTA2VR","Brooke","Dotson","Euismod Enim PC","+37064624083","amet@erosturpisnon.net","2623 Ac Rd."),
    ("B9536827","DVR10CON8KW","Harriet","Chambers","Sit Amet Diam PC","+37064760325","sollicitudin.a@Mauriseuturpis.com","8152 Nulla Street"),
    ("B2289768","EGW65RAT9FR","Kevin","Cannon","Nascetur Limited","+37069008109","semper.et.lacinia@aptent.org","Ap #287-9858 Orci, Road"),
    ("B5711309","EPF30LTA2VR","Lara","Mann","Non Arcu Vivamus Consulting","+37065631330","libero@atarcu.com","P.O. Box 193, 9754 Ultrices, St."),
    ("B4297760","BTP68ODG0CN","Hermione","Johnson","Mattis Semper Dui PC","+37067654656","Mauris.vestibulum@NullafacilisiSed.org","9297 Dolor Road"),
    ("B7520795","EPF30LTA2VR","Callum","Huffman","Egestas Limited","+37063333319","amet.lorem@in.org","674-4999 Arcu. Street");

INSERT INTO `T_darbuotojai` (`C_id`,`T_padaliniai_C_padalinio_id`,`C_vardas`,`C_pavarde`,`C_pareigos`,`C_tel_nr`,`C_el_p`,`C_gyven_adr`) 
    VALUES 
    ("B6744220","EPF30LTA2VR","Adara","Key","Aenean Egestas LLP","+37062336584","risus@a.net","Ap #517-4628 Nunc Street"),
    ("B9402458","AJY33MTZ1YO","Lunea","Emerson","Nulla Incorporated","+37063591696","egestas@Nullamut.ca","4108 Enim St."),
    ("B9029451","CGP66CWN3QO","Olympia","Pace","Tellus Non Corp.","+37060355537","vitae.erat.vel@elementumpurusaccumsan.co.uk","Ap #527-6163 Ornare, St."),
    ("B9726734","DEU13ZZD2EV","Fritz","Cleveland","Et Pede Institute","+37069089509","commodo@Praesent.net","Ap #178-8968 Nonummy Ave"),
    ("B3419767","BQS64AHF8YM","Alyssa","Hart","Parturient Montes Institute","+37068510343","dignissim.pharetra@Pellentesque.ca","539-2435 A Ave"),
    ("B1322479","DEU13ZZD2EV","Joan","Lott","Scelerisque Sed Sapien LLP","+37060577019","consectetuer.adipiscing@Proinvelarcu.net","Ap #955-4411 Magna Road"),
    ("B8165418","DVR10CON8KW","Kylan","Cohen","Et Rutrum Non Incorporated","+37063217486","sociis.natoque.penatibus@Donec.edu","P.O. Box 752, 719 Orci. Ave"),
    ("B7111325","DIV94LVF3JE","Sigourney","Garcia","Vitae Odio Sagittis Consulting","+37066112029","Vivamus.sit.amet@Phasellus.ca","Ap #444-9762 Dolor Avenue"),
    ("B7823188","EPF30LTA2VR","Camille","Jennings","Magnis Consulting","+37066612469","dictum@quamvel.org","Ap #202-2954 Consectetuer Av."),
    ("B4352268","BQS64AHF8YM","Cora","Witt","Ut Corp.","+37067466721","Cum.sociis@Maurisvelturpis.com","Ap #398-3463 Fringilla St.");

INSERT INTO `T_darbuotojai` (`C_id`,`T_padaliniai_C_padalinio_id`,`C_vardas`,`C_pavarde`,`C_pareigos`,`C_tel_nr`,`C_el_p`,`C_gyven_adr`) 
    VALUES 
    ("B6877032","EGW65RAT9FR","Hilda","Bell","Fusce Foundation","+37060517991","dolor.elit.pellentesque@eratvelpede.ca","P.O. Box 149, 6544 Vehicula Ave"),
    ("B3330735","DEU13ZZD2EV","Hilda","Newton","Congue Turpis In Ltd","+37069518260","Cras.dolor.dolor@diam.com","P.O. Box 267, 1065 Suspendisse Av."),
    ("B8567791","AJY33MTZ1YO","Armando","Rhodes","Odio Consulting","+37066687218","a@temporbibendumDonec.co.uk","P.O. Box 565, 7538 Fringilla St."),
    ("B5079411","CSH94ZZA1FF","Debra","Jacobs","Dignissim Pharetra Nam Industries","+37061500325","magna@SednequeSed.ca","Ap #774-107 Lorem St."),
    ("B5358597","BTP68ODG0CN","Rama","Underwood","Est Ac Consulting","+37068056185","ac.orci.Ut@sapienCrasdolor.edu","P.O. Box 276, 8711 Ipsum. St."),
    ("B4141624","BQS64AHF8YM","Myra","Alston","Consectetuer Adipiscing Company","+37068085317","lacus@ligula.net","P.O. Box 699, 8328 Mattis St."),
    ("B5801386","DVR10CON8KW","Stewart","Shields","Mauris Sapien Limited","+37063059041","vel.est@non.net","376-5353 Sed Street"),
    ("B3088903","DIV94LVF3JE","Robert","Cantrell","Feugiat Lorem PC","+37068543266","penatibus@tinciduntdui.edu","452-5195 Et Rd."),
    ("B1315419","DEU13ZZD2EV","Tobias","Rice","Parturient Consulting","+37062413016","mollis@adipiscingnonluctus.org","8063 Aliquam Ave"),
    ("B1960641","EGW65RAT9FR","Troy","Watts","Lobortis Ultrices Inc.","+37067862244","dolor.Fusce@sapiengravidanon.edu","358-1717 Cursus Road");

INSERT INTO `T_darbuotojai` (`C_id`,`T_padaliniai_C_padalinio_id`,`C_vardas`,`C_pavarde`,`C_pareigos`,`C_tel_nr`,`C_el_p`,`C_gyven_adr`) 
    VALUES 
    ("B6274553","EGW65RAT9FR","Rosalyn","Villarreal","Rutrum Justo Praesent Incorporated","+37069714346","at@loremeget.ca","157-4370 Nonummy St."),
    ("B4928546","EPF30LTA2VR","Felicia","Levy","Ultricies Foundation","+37068756976","Suspendisse.ac.metus@pellentesque.ca","Ap #682-1023 Porttitor Ave"),
    ("B8632059","DEU13ZZD2EV","Alexandra","Roach","Donec Est Mauris Associates","+37060538592","neque@rutrum.ca","246-846 Magna. St."),
    ("B9575676","EPF30LTA2VR","Destiny","Everett","Mauris Institute","+37063610653","sollicitudin.adipiscing@consectetuereuismodest.edu","P.O. Box 736, 1399 Nam St."),
    ("B0775972","EGW65RAT9FR","Kieran","Rojas","Sed Pede Associates","+37062636364","lorem@Suspendissesed.co.uk","P.O. Box 329, 8848 Lorem Avenue"),
    ("B8712256","EGW65RAT9FR","Cameron","Solomon","Malesuada Incorporated","+37069050043","morbi@vel.net","Ap #294-6540 Quis Ave"),
    ("B4764221","BQS64AHF8YM","Reece","Doyle","Vitae Semper Inc.","+37063539185","non.arcu@rutrumeuultrices.edu","353-1500 Aliquet, St."),
    ("B2614557","BQS64AHF8YM","Laith","Drake","Nisl Corp.","+37069531429","magna.tellus@erat.co.uk","513 Eu Rd."),
    ("B2925990","AJY33MTZ1YO","Cruz","Deleon","Vel Vulputate Ltd","+37067733090","a@loremsemper.co.uk","554-4633 Risus. Rd."),
    ("B5925343","DVR10CON8KW","TaShya","Wolf","A Arcu Ltd","+37069863757","nec.ante@tinciduntpede.edu","Ap #157-8536 A St.");

INSERT INTO `T_darbuotojai` (`C_id`,`T_padaliniai_C_padalinio_id`,`C_vardas`,`C_pavarde`,`C_pareigos`,`C_tel_nr`,`C_el_p`,`C_gyven_adr`) 
    VALUES 
    ("B8744528","EPF30LTA2VR","Tanya","Alvarado","Vulputate Eu Odio PC","+37064724492","nunc.est.mollis@Duismienim.co.uk","752-5058 Facilisis. St."),
    ("B3217445","DVR10CON8KW","Charde","Park","Mauris Molestie LLC","+37068551379","egestas.ligula.Nullam@nisimagnased.ca","P.O. Box 364, 2224 Ornare Ave"),
    ("B0163638","CSH94ZZA1FF","Sacha","Boyer","Nunc Sit Ltd","+37066658035","vel.lectus.Cum@etmalesuada.net","Ap #913-2735 Aenean Av."),
    ("B5019924","CSH94ZZA1FF","Lunea","Mckenzie","Amet Faucibus Limited","+37068252113","nulla.In.tincidunt@orcitinciduntadipiscing.org","Ap #237-8075 Vitae, Rd."),
    ("B1623777","EGW65RAT9FR","Dustin","Mcdaniel","Sed Pede LLC","+37067052911","elementum@velconvallis.edu","Ap #380-7526 Fringilla Av."),
    ("B3408913","CSH94ZZA1FF","Jeanette","Osborn","Amet Company","+37062988846","vestibulum@Praesentinterdum.com","P.O. Box 738, 7370 Quis, St."),
    ("B6876710","BTP68ODG0CN","Charity","Lancaster","Augue Malesuada Corp.","+37062052973","porttitor.interdum@lacus.com","P.O. Box 679, 678 Tristique Rd."),
    ("B3667647","CSH94ZZA1FF","Lee","Wheeler","Condimentum Eget Limited","+37067934583","egestas.a.scelerisque@augueeutellus.co.uk","903-3325 Consequat Ave"),
    ("B9177089","AJY33MTZ1YO","Phillip","Fernandez","Arcu Eu Odio Corp.","+37069056499","sagittis.felis@dapibusgravida.com","398-4127 Pede. Street"),
    ("B8493682","BTP68ODG0CN","Len","Mayo","Varius Et Euismod Foundation","+37063436436","iaculis@quam.com","833-1748 Orci Avenue");

INSERT INTO `T_darbuotojai` (`C_id`,`T_padaliniai_C_padalinio_id`,`C_vardas`,`C_pavarde`,`C_pareigos`,`C_tel_nr`,`C_el_p`,`C_gyven_adr`) 
    VALUES 
    ("B7843916","BQS64AHF8YM","Rama","Morton","Luctus Corporation","+37062648913","facilisis.eget.ipsum@faucibusorci.com","Ap #295-5703 Netus Ave"),
    ("B5576178","CSH94ZZA1FF","Merrill","Gibbs","Eu Neque Corporation","+37069563367","dolor@vitaedolor.org","P.O. Box 283, 7308 Bibendum Street"),
    ("B0470785","DIV94LVF3JE","Regina","Cleveland","Nulla Facilisis LLC","+37069297056","magnis@enim.co.uk","2332 Nec, Rd."),
    ("B5162281","CSB94WDI8GG","Signe","Vaughan","Placerat Velit Quisque Foundation","+37062894542","sit.amet@Aeneanegestashendrerit.edu","P.O. Box 180, 1908 Sed St."),
    ("B2297146","DIV94LVF3JE","Norman","Lynch","Ipsum Leo Limited","+37060774400","Nullam.suscipit@Suspendissenon.net","8858 Pede Rd."),
    ("B0593801","DVR10CON8KW","Ima","Sloan","Commodo Tincidunt Institute","+37060476972","a.mi@velfaucibusid.net","P.O. Box 552, 7299 Nunc Rd."),
    ("B2710672","DEU13ZZD2EV","Christen","Macias","Aenean Corporation","+37063160135","mus.Donec@sed.ca","862-813 Laoreet, St."),
    ("B9633722","EGW65RAT9FR","Solomon","Richmond","Purus Accumsan Industries","+37068788429","felis.Nulla.tempor@fermentumvel.edu","639-993 Nunc. Avenue"),
    ("B7172629","AJY33MTZ1YO","Lydia","Hodge","Amet Lorem PC","+37068296942","accumsan.sed@luctus.ca","P.O. Box 916, 5215 Integer Rd."),
    ("B4760736","CSH94ZZA1FF","Zelenia","Jennings","Neque Consulting","+37062291379","ultrices@penatibuset.ca","P.O. Box 941, 7124 Nec St.");

INSERT INTO `T_darbuotojai` (`C_id`,`T_padaliniai_C_padalinio_id`,`C_vardas`,`C_pavarde`,`C_pareigos`,`C_tel_nr`,`C_el_p`,`C_gyven_adr`) 
    VALUES 
    ("B3056716","CSH94ZZA1FF","Dahlia","Hubbard","Semper Erat Corporation","+37060593992","eget.metus.In@primisinfaucibus.net","4016 Felis Rd."),
    ("B5806048","AJY33MTZ1YO","Medge","Marquez","Sit Amet Inc.","+37061733365","quis.accumsan@erat.com","782-7991 Eu St."),
    ("B5176063","BQS64AHF8YM","Rylee","Ayers","Accumsan Sed Incorporated","+37060409601","per.conubia@augue.co.uk","1878 Velit. St."),
    ("B3970930","AJY33MTZ1YO","Amanda","Miller","Sit Amet Inc.","+37062048884","purus.mauris.a@Nunc.org","234-301 Ipsum. Rd."),
    ("B4499431","CSH94ZZA1FF","Julian","Walter","Quis Lectus LLP","+37066830905","In@duiCraspellentesque.ca","7799 Sed Rd."),
    ("B4440830","CSB94WDI8GG","Karyn","Fuller","Dictum Proin Eget Corporation","+37065104231","sem.eget.massa@sodales.ca","P.O. Box 870, 507 Ultrices Road"),
    ("B1512445","BQS64AHF8YM","Warren","Christian","Non Ltd","+37065473188","cursus@odiosempercursus.co.uk","1440 Ut Av."),
    ("B8765431","AJY33MTZ1YO","Damian","Schroeder","Hendrerit A Arcu LLC","+37067542566","et@semper.com","P.O. Box 190, 9812 Integer St."),
    ("B2747082","EPF30LTA2VR","Anjolie","Cash","Ullamcorper Magna Sed Industries","+37062646583","Etiam.laoreet.libero@sodalesnisimagna.net","P.O. Box 400, 6001 Iaculis, Street"),
    ("B1451326","CSH94ZZA1FF","Amity","Bowen","Nunc Nulla Company","+37063730920","risus@necimperdietnec.edu","Ap #449-9509 Mauris. St.");




















## T_sutartys

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-1l37ptP0","2015-11-24 21:51:53","23.07"),
    ("SUT-2t06TTu8","2015-03-30 12:30:30","42.83"),
    ("SUT-5h66wgr8","2015-09-04 23:02:53","44.98"),
    ("SUT-4L02ASg5","2015-07-02 03:13:48","33.17"),
    ("SUT-6v14dqm2","2016-07-10 12:27:23","25.85"),
    ("SUT-9A56AdF3","2016-09-02 15:23:25","61.28"),
    ("SUT-9j02dlT4","2015-06-07 02:13:24","59.76"),
    ("SUT-8T53UyG6","2015-04-28 05:42:54","53.90"),
    ("SUT-3l76Pnl7","2015-07-31 04:50:16","67.87"),
    ("SUT-6C13PsB4","2015-02-03 15:53:07","87.32");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-8R43Cun2","2015-04-25 01:51:43","95.99"),
    ("SUT-2E96UrW2","2016-10-22 21:58:02","71.47"),
    ("SUT-0j52gmB8","2016-03-31 19:51:26","23.96"),
    ("SUT-7z04tVG7","2015-10-11 08:26:33","66.15"),
    ("SUT-3o01uTx4","2016-10-03 23:18:53","19.38"),
    ("SUT-6s85MAF5","2016-05-31 02:23:38","42.70"),
    ("SUT-3K86iFE2","2015-11-14 13:07:27","25.16"),
    ("SUT-8H21wYZ9","2016-05-19 00:18:10","86.44"),
    ("SUT-9r17DEP6","2016-03-11 09:21:38","18.42"),
    ("SUT-7I73TGW2","2016-01-10 10:34:45","31.94");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-8O74mgf6","2016-04-29 23:42:11","55.94"),
    ("SUT-2i19yfz0","2015-03-09 19:22:00","79.90"),
    ("SUT-5U05KMq2","2016-09-16 16:15:15","79.87"),
    ("SUT-5h73CYN0","2015-02-22 21:11:06","22.09"),
    ("SUT-1I73kvU8","2016-02-22 08:50:44","32.02"),
    ("SUT-8d17fyc1","2016-12-08 23:04:11","46.78"),
    ("SUT-1q31Zqc4","2016-01-29 10:38:07","99.05"),
    ("SUT-4O62jdc1","2015-02-01 12:46:41","85.02"),
    ("SUT-6K06xTj5","2015-12-25 21:15:22","53.87"),
    ("SUT-3k42WNu5","2016-05-08 18:55:03","22.49");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-8E99LgE2","2015-12-07 06:46:57","96.58"),
    ("SUT-5s81Gts7","2015-01-12 18:10:21","72.05"),
    ("SUT-0t63nXf7","2015-02-04 15:47:19","19.94"),
    ("SUT-3m04RbH9","2015-03-06 18:16:46","13.35"),
    ("SUT-1c60YaB6","2016-09-18 10:39:43","49.80"),
    ("SUT-3k43ikM7","2015-04-10 22:40:53","44.88"),
    ("SUT-1e72nnN3","2016-06-14 19:16:22","34.06"),
    ("SUT-1u33kMu0","2016-11-03 07:30:30","51.02"),
    ("SUT-1W95QvU6","2016-07-04 16:28:09","68.90"),
    ("SUT-9e90QRM3","2015-06-14 05:55:52","92.15");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-9i85SrJ2","2015-05-10 06:35:11","67.36"),
    ("SUT-8a64tZa8","2015-04-09 17:43:46","86.30"),
    ("SUT-8Z93BCB4","2016-05-08 21:57:56","83.04"),
    ("SUT-5c85Zry8","2016-04-25 18:35:17","16.85"),
    ("SUT-5Y11jth0","2015-01-09 22:32:51","14.50"),
    ("SUT-8o15XOP8","2016-06-12 07:17:20","25.59"),
    ("SUT-0e35epl7","2016-09-18 05:00:23","82.93"),
    ("SUT-8C09NjQ8","2015-07-15 18:17:03","56.12"),
    ("SUT-8G80ZPO0","2015-03-19 10:46:50","89.96"),
    ("SUT-5w74ESH8","2016-09-16 09:12:31","91.22");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-5u22AWZ0","2016-11-10 08:38:51","84.30"),
    ("SUT-3t31Wwu9","2015-02-10 02:05:30","17.25"),
    ("SUT-9U61ONF8","2016-02-28 15:16:44","62.20"),
    ("SUT-3L60tKP3","2016-05-25 23:25:30","77.99"),
    ("SUT-5M33iFG5","2015-05-30 12:28:07","23.55"),
    ("SUT-3m99tnQ0","2015-05-26 04:27:02","33.49"),
    ("SUT-6L96cYQ2","2015-05-12 03:57:56","75.09"),
    ("SUT-4g98KbG7","2016-05-25 05:29:38","93.98"),
    ("SUT-2w65MgJ3","2016-05-12 02:38:58","22.18"),
    ("SUT-3E89uJv1","2016-06-16 17:16:52","89.71");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-6s79rbW5","2016-05-09 23:11:26","67.12"),
    ("SUT-6Q16uAa6","2016-11-04 20:30:10","68.33"),
    ("SUT-9H69kQc7","2016-01-08 22:15:31","49.03"),
    ("SUT-1W20IZF2","2015-08-20 09:43:13","67.55"),
    ("SUT-5d98RkI1","2015-10-22 10:49:16","53.29"),
    ("SUT-7K09Knh5","2015-04-16 17:44:21","74.72"),
    ("SUT-7e83EyL9","2015-10-09 18:40:30","85.00"),
    ("SUT-0F10uLS1","2015-10-01 17:46:14","79.14"),
    ("SUT-8I05bJA7","2016-02-05 12:24:12","78.07"),
    ("SUT-1m53BNT1","2016-04-29 20:05:58","41.32");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-6r59GxE2","2015-12-09 01:53:16","88.50"),
    ("SUT-9j56EuK5","2016-06-14 09:27:04","87.39"),
    ("SUT-8K20ZkV3","2015-01-06 09:45:46","16.64"),
    ("SUT-6Z49tJQ0","2016-01-28 18:48:35","39.92"),
    ("SUT-3S94OLf4","2016-04-20 13:05:36","92.78"),
    ("SUT-1m97rKu4","2016-04-04 19:59:16","94.44"),
    ("SUT-8H15DrS3","2016-08-08 05:16:29","85.02"),
    ("SUT-2P99tJH4","2016-01-08 15:35:26","46.77"),
    ("SUT-2O61lNb9","2015-10-22 03:45:39","65.41"),
    ("SUT-8x32RoK1","2016-07-05 22:11:14","76.61");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-5u64TEn9","2016-05-18 02:04:48","74.04"),
    ("SUT-4a70Epl0","2016-12-13 13:47:07","12.05"),
    ("SUT-5D89TSh2","2015-02-10 09:34:34","37.68"),
    ("SUT-9E91YGe7","2015-08-11 16:09:36","59.72"),
    ("SUT-9n48GyU0","2016-10-08 10:11:22","69.13"),
    ("SUT-9M78OmA9","2016-01-21 15:48:48","48.97"),
    ("SUT-3H68uxr8","2015-02-22 01:15:15","68.25"),
    ("SUT-0T31rXT1","2016-05-08 17:52:17","82.61"),
    ("SUT-5I83mRo5","2016-03-14 14:54:20","68.24"),
    ("SUT-6s17CdZ1","2015-03-27 21:54:08","93.88");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-8C24aRm0","2016-07-12 13:08:09","34.28"),
    ("SUT-4X19JxH5","2015-05-24 21:03:50","51.57"),
    ("SUT-7Y15gZG5","2016-02-17 11:19:47","27.04"),
    ("SUT-7F98hbD2","2016-02-29 11:12:08","62.97"),
    ("SUT-4f70Lcq5","2016-05-01 12:12:40","13.99"),
    ("SUT-4l27rwX2","2016-03-26 14:15:24","86.16"),
    ("SUT-8D95EfG7","2016-08-25 10:40:57","47.47"),
    ("SUT-6c50zje6","2016-07-25 03:17:53","39.87"),
    ("SUT-3J90cEl6","2015-10-04 10:45:40","21.70"),
    ("SUT-7w15gjk5","2015-09-16 12:20:22","43.72");
INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-1T36ylt0","2015-07-31 12:43:59","023.57"),
    ("SUT-9T54qcn9","2015-07-19 12:00:34","120.46"),
    ("SUT-8X02KzI7","2015-08-28 01:38:47","832.14"),
    ("SUT-6v60Lme8","2015-06-22 14:43:53","819.84"),
    ("SUT-2S22IDx1","2015-09-10 19:19:39","488.88"),
    ("SUT-8Y84TQS7","2015-02-20 23:38:23","062.48"),
    ("SUT-1O41kBb5","2015-04-07 11:11:48","700.18"),
    ("SUT-9x35Ryv7","2015-04-05 22:32:09","541.84"),
    ("SUT-5d42ugn4","2015-09-27 13:51:19","912.14"),
    ("SUT-8u84JHG0","2015-11-06 21:05:15","661.79");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-1I27ZMS4","2015-04-16 02:06:05","091.23"),
    ("SUT-2R93uDc1","2015-02-13 13:37:46","498.61"),
    ("SUT-0L70LkV2","2015-11-01 12:13:05","589.95"),
    ("SUT-4F38Ahl5","2015-04-24 10:12:47","030.25"),
    ("SUT-1I52XWl3","2015-10-21 14:34:00","813.25"),
    ("SUT-5A71qIC9","2015-07-14 20:57:31","325.46"),
    ("SUT-8t53ZEw8","2015-01-08 23:29:01","504.98"),
    ("SUT-6C37wXw6","2015-01-06 08:51:41","249.14"),
    ("SUT-7W10XRc4","2015-05-04 00:27:33","843.55"),
    ("SUT-7E29bNx2","2015-04-28 09:11:10","548.78");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-0h17iJR5","2015-03-17 13:39:50","504.74"),
    ("SUT-6I62UsB6","2015-06-07 04:31:03","305.81"),
    ("SUT-1P95xYA2","2015-10-12 21:18:25","719.43"),
    ("SUT-1x09Zcx6","2015-07-29 03:44:57","253.33"),
    ("SUT-3P05Kdo7","2015-03-04 12:23:53","075.55"),
    ("SUT-5o83pBi1","2015-09-19 00:31:21","314.95"),
    ("SUT-4Z23ZAR8","2015-01-16 00:21:23","217.33"),
    ("SUT-1L02Dxr3","2015-11-14 02:26:25","605.57"),
    ("SUT-4F49ibN4","2015-06-03 18:55:12","605.94"),
    ("SUT-8f16SmG2","2015-02-15 09:50:07","548.46");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-1P11ljK3","2015-07-22 04:37:00","818.72"),
    ("SUT-6W53IOO1","2015-04-29 06:12:00","114.00"),
    ("SUT-1X33mOA6","2015-04-28 13:53:08","860.53"),
    ("SUT-7N87lDB2","2015-10-12 20:50:33","717.19"),
    ("SUT-5d35FlH0","2015-07-15 10:54:04","822.46"),
    ("SUT-1O99YPM5","2015-03-13 15:53:47","406.69"),
    ("SUT-9z62qBJ2","2015-08-18 11:15:26","005.08"),
    ("SUT-7l71ocb3","2015-07-16 17:59:50","530.73"),
    ("SUT-6w98nGV2","2015-03-14 11:51:41","652.13"),
    ("SUT-7N78bwB8","2015-01-10 07:17:15","048.89");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-0x22qQJ2","2015-02-08 14:24:33","397.13"),
    ("SUT-4R63Gaq1","2015-02-02 23:12:46","244.97"),
    ("SUT-8L39ZPQ4","2015-05-20 23:22:01","650.81"),
    ("SUT-3K81PPi2","2015-09-11 19:12:29","937.46"),
    ("SUT-5Y25qff0","2015-11-13 04:33:18","578.41"),
    ("SUT-1K50zuO4","2015-04-23 19:23:40","620.60"),
    ("SUT-0Q93EZD3","2015-03-16 15:09:07","318.55"),
    ("SUT-6h80acj6","2015-07-31 15:14:13","423.15"),
    ("SUT-3L48JMa9","2015-01-12 13:41:01","049.43"),
    ("SUT-4w97zVJ1","2015-10-18 06:04:07","675.95");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-1Z57Ksr0","2015-01-12 09:00:39","454.31"),
    ("SUT-2w83hks9","2015-08-05 14:42:55","322.83"),
    ("SUT-1K64oww8","2015-06-07 10:12:33","030.92"),
    ("SUT-9t93xGA3","2015-06-16 10:37:50","904.93"),
    ("SUT-1J22fLW8","2015-09-10 14:05:02","920.71"),
    ("SUT-1n63eII7","2015-01-14 13:00:37","515.44"),
    ("SUT-6b99pnD2","2015-10-24 10:54:56","184.56"),
    ("SUT-9t52WAY7","2015-07-21 00:07:40","224.18"),
    ("SUT-6O43TrC5","2015-10-01 04:37:52","507.92"),
    ("SUT-0u02gyj0","2015-06-15 22:05:58","324.23");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-9Q80ldM3","2015-06-05 23:51:20","259.72"),
    ("SUT-8C80KYq5","2015-05-03 00:24:54","343.41"),
    ("SUT-0q32mhz0","2015-07-11 16:03:47","306.13"),
    ("SUT-6o27cMq7","2015-06-10 08:41:07","863.48"),
    ("SUT-7D74VlE0","2015-01-09 18:00:30","007.04"),
    ("SUT-2N66tji8","2015-10-10 20:04:20","914.51"),
    ("SUT-3H18nVk0","2015-08-15 10:37:09","377.15"),
    ("SUT-1w28rJY4","2015-10-07 13:23:48","704.16"),
    ("SUT-7k00cOM5","2015-10-07 06:28:47","095.71"),
    ("SUT-6q25wdL3","2015-05-21 10:01:59","262.53");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-4Q54YHa6","2015-08-04 08:16:20","767.56"),
    ("SUT-5K31odq3","2015-09-05 22:42:07","605.91"),
    ("SUT-5X27yWX1","2015-11-06 09:56:12","556.34"),
    ("SUT-5Y15scd9","2015-02-23 14:35:21","082.94"),
    ("SUT-5Y10EOf5","2015-04-12 14:03:23","194.37"),
    ("SUT-1B69CSm3","2015-10-06 01:23:11","440.16"),
    ("SUT-5s81KCQ5","2015-02-08 08:25:38","709.80"),
    ("SUT-7t35eEW2","2015-07-12 11:43:48","434.86"),
    ("SUT-7r74PuE6","2015-06-17 17:04:17","039.72"),
    ("SUT-2m01NMg0","2015-10-20 04:19:58","604.39");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-8z62bAU0","2015-08-01 13:52:11","436.75"),
    ("SUT-9a75mps9","2015-07-01 05:56:24","204.75"),
    ("SUT-4s62AoA7","2015-09-01 12:47:00","373.98"),
    ("SUT-3D31hew3","2015-07-18 00:13:46","239.50"),
    ("SUT-2A20WkQ1","2015-10-12 20:11:17","727.99"),
    ("SUT-6K50CWS6","2015-08-17 17:25:51","208.15"),
    ("SUT-6R38fTV7","2015-08-16 18:38:11","671.20"),
    ("SUT-0t98Iwr2","2015-04-23 06:24:57","588.60"),
    ("SUT-3g82RgT4","2015-11-09 20:58:09","812.40"),
    ("SUT-8t24cRN2","2015-02-02 05:30:55","634.39");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-9n34OIe7","2015-07-17 19:39:24","039.22"),
    ("SUT-8l48OvN5","2015-03-11 20:15:14","986.38"),
    ("SUT-4T57Cmz3","2015-07-26 20:40:44","809.88"),
    ("SUT-0b61OAL6","2015-11-30 03:55:53","127.67"),
    ("SUT-8o27AYH8","2015-01-15 20:20:19","277.33"),
    ("SUT-0d99Irm6","2015-05-11 05:39:24","923.00"),
    ("SUT-0t36Gem2","2015-01-01 22:10:56","760.61"),
    ("SUT-5E21ztP7","2015-01-18 01:42:57","144.32"),
    ("SUT-0Y10Odl3","2015-06-06 15:53:49","410.50"),
    ("SUT-4A28kYT3","2015-03-24 08:32:14","027.63");
INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-8J22dqx4","2015-09-08 10:56:53","770.12"),
    ("SUT-8F99ozn3","2015-02-19 10:39:36","369.09"),
    ("SUT-6Y77XfS0","2015-08-13 18:06:34","019.12"),
    ("SUT-0u19yvG8","2015-08-09 03:40:45","856.38"),
    ("SUT-0U71ime4","2015-08-10 20:26:59","571.01"),
    ("SUT-7d75Dae9","2015-03-03 00:29:59","297.89"),
    ("SUT-5q04NxL6","2015-09-05 10:37:37","673.44"),
    ("SUT-3P84Pvi7","2015-10-28 20:33:04","380.21"),
    ("SUT-4u27Swk9","2015-04-23 01:52:57","411.22"),
    ("SUT-4n21Icw4","2015-06-27 03:09:39","939.78");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-4U19odQ3","2015-08-15 17:13:38","042.50"),
    ("SUT-7l09fvg8","2015-08-01 08:40:13","367.65"),
    ("SUT-5N23pmN5","2015-05-08 17:41:12","143.15"),
    ("SUT-4w17guN3","2015-04-08 09:59:24","672.98"),
    ("SUT-5S82DCL3","2015-07-19 07:01:08","799.65"),
    ("SUT-2B57yIE4","2015-10-10 10:52:18","720.06"),
    ("SUT-2R16Nxc3","2014-12-31 01:46:44","731.71"),
    ("SUT-2k66cNW2","2015-07-18 05:58:29","003.55"),
    ("SUT-6U76FKo2","2015-01-16 07:55:33","975.73"),
    ("SUT-0I15zCW0","2015-08-26 16:26:31","633.34");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-1i69RSo9","2015-03-21 13:13:27","181.30"),
    ("SUT-1h98FzB0","2015-11-16 19:05:11","376.00"),
    ("SUT-4r93RTf4","2015-04-01 06:21:02","641.08"),
    ("SUT-2J11HPI7","2015-01-18 08:58:43","412.74"),
    ("SUT-5y05aan7","2015-05-10 21:20:23","122.64"),
    ("SUT-8v84jIO4","2015-09-10 17:25:35","205.88"),
    ("SUT-8m59vjJ1","2015-01-13 19:42:28","592.27"),
    ("SUT-0B95VsW1","2015-03-23 06:57:48","007.19"),
    ("SUT-9c73wFS7","2015-09-06 00:41:10","196.24"),
    ("SUT-8j71DHx9","2015-11-06 13:35:28","133.30");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-6f68UQe7","2015-10-12 00:58:08","549.07"),
    ("SUT-3V89tfz4","2015-05-17 08:19:45","530.47"),
    ("SUT-2w12gKM1","2015-10-21 08:28:10","269.27"),
    ("SUT-1B92Yzp7","2015-11-02 16:24:28","806.46"),
    ("SUT-8O27VpN8","2015-08-17 12:33:40","455.16"),
    ("SUT-3y87HAJ7","2015-02-27 19:31:20","316.93"),
    ("SUT-1g99QyH9","2015-06-15 03:14:56","209.98"),
    ("SUT-3B98zOH4","2015-07-17 23:08:40","683.36"),
    ("SUT-1r90ClE1","2015-02-16 18:24:04","166.38"),
    ("SUT-0I46dkt1","2015-09-14 03:03:33","758.13");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-7w24UvC4","2015-04-19 14:33:31","367.64"),
    ("SUT-0P16TyI8","2015-10-19 07:14:26","416.46"),
    ("SUT-9Z76uMW7","2015-06-14 16:31:07","953.47"),
    ("SUT-3l58QoC6","2015-10-08 02:37:51","948.45"),
    ("SUT-7h29phO8","2015-07-02 07:31:46","206.26"),
    ("SUT-5p50gaA0","2015-08-08 12:58:03","408.93"),
    ("SUT-0v71kce0","2015-10-31 02:45:19","330.11"),
    ("SUT-7T13wtc8","2015-04-27 17:54:12","826.78"),
    ("SUT-4h16zWz6","2015-10-31 22:38:31","355.61"),
    ("SUT-2I74bwB0","2015-02-17 20:32:58","053.01");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-4r62vSG3","2015-05-28 18:04:47","062.64"),
    ("SUT-6M56lTg1","2015-08-01 05:01:07","166.84"),
    ("SUT-2Z82zPn0","2015-07-22 07:25:24","030.99"),
    ("SUT-7Q27flk5","2015-02-13 03:05:31","500.57"),
    ("SUT-5V91Oyx8","2015-10-11 12:13:57","738.74"),
    ("SUT-0t96inu8","2015-04-19 06:55:34","289.54"),
    ("SUT-5Z25koJ1","2015-03-30 19:04:27","602.67"),
    ("SUT-7b62riD7","2015-02-06 11:53:25","392.78"),
    ("SUT-9y50oVj5","2015-01-18 19:03:54","103.94"),
    ("SUT-3v72FEA4","2015-07-23 11:50:37","352.28");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-5j66CIW5","2015-06-08 17:51:04","590.12"),
    ("SUT-8l34UHN9","2015-11-28 19:50:41","611.08"),
    ("SUT-7i04CzH4","2015-05-30 11:46:39","987.59"),
    ("SUT-2L21EBR3","2015-10-20 16:27:22","299.95"),
    ("SUT-0z06REc4","2015-07-28 21:55:37","136.38"),
    ("SUT-5b47UYK9","2015-04-07 12:36:51","317.08"),
    ("SUT-8d34uBb4","2015-05-04 14:53:34","021.03"),
    ("SUT-7H07HAV9","2015-08-26 08:21:21","317.53"),
    ("SUT-3d72zYB0","2015-04-28 23:56:19","040.07"),
    ("SUT-0Z88TBB1","2015-07-25 20:33:04","853.96");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-8e35Imj3","2015-11-14 22:55:35","035.09"),
    ("SUT-4C04Rgb1","2015-09-15 03:56:57","822.93"),
    ("SUT-3j82pXe3","2015-04-20 10:22:17","511.23"),
    ("SUT-8Z73Uum3","2015-10-21 23:38:09","522.70"),
    ("SUT-2L55NxL9","2015-06-03 05:16:50","334.09"),
    ("SUT-6K75lBA7","2015-08-01 11:15:55","558.63"),
    ("SUT-3s72iMq1","2015-06-23 06:00:16","153.08"),
    ("SUT-7D55dGE8","2015-11-13 19:15:08","655.19"),
    ("SUT-9D02sLt3","2015-10-03 05:09:44","649.31"),
    ("SUT-3r73mCI7","2015-04-11 03:03:19","438.47");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-0c13Tnp5","2015-10-22 12:11:48","591.53"),
    ("SUT-9K35cOa7","2015-01-07 11:51:12","861.86"),
    ("SUT-0L86ELB2","2015-09-21 02:07:34","935.14"),
    ("SUT-5v42Weu0","2015-11-04 22:32:25","606.63"),
    ("SUT-0V61ive4","2015-05-27 07:39:32","808.74"),
    ("SUT-6T52rzN0","2015-01-17 18:24:02","963.94"),
    ("SUT-6i90hkY3","2015-01-29 02:04:39","502.44"),
    ("SUT-6g60woO5","2015-10-29 07:00:33","277.14"),
    ("SUT-8p82oUD1","2015-09-24 05:21:22","008.85"),
    ("SUT-2k12toI6","2015-06-24 05:47:37","214.89");

INSERT INTO `T_sutartys` (`C_numeris`,`C_sudarymo_data`,`C_suma`) 
    VALUES 
    ("SUT-3n65UqS7","2015-04-28 00:16:13","157.81"),
    ("SUT-9V10mnE6","2015-04-02 07:16:18","064.86"),
    ("SUT-7E21RWs1","2015-03-23 14:22:20","853.73"),
    ("SUT-5d60ypP6","2015-06-18 08:56:01","663.43"),
    ("SUT-6e14NLc2","2015-01-12 11:03:53","868.91"),
    ("SUT-1W24kuR0","2015-04-09 06:11:59","843.98"),
    ("SUT-3m03dwf3","2015-08-27 15:53:20","770.60"),
    ("SUT-4O53rUQ6","2015-01-14 07:53:41","244.13"),
    ("SUT-0y19lCt1","2015-09-25 14:23:16","523.09"),
    ("SUT-2U40TtQ2","2015-05-25 12:32:56","646.75");











## T_tiekeju_sutartys
## echo "${a}" |tr -d '\n' |sed -e 's/YYYYYYYYYYY/\n/g' | while read line; do echo -e "${line}${sutID[$(($((${RANDOM}*${RANDOM}))%${#sutID[@]}))]}"; done |tr -d '\n'|sed -e 's/;/;\n/g' |tr -d '\n' |sed -e 's/AAAAAAAAAA/\n/g' | while read line; do echo -e "${line}${darbID[$((${RANDOM}%${#darbID[@]}))]}"; done |tr -d '\n'|sed -e 's/;/;\n/g' -e 's/),/),\n\t/g' -e 's/VALUES (/\n\tVALUES \n\t(/g'


INSERT INTO `T_tiekeju_sutartys` (`C_numeris`,`C_numeris_tiekejo`,`T_darbuotojai_C_id`,`C_sutarties_objektas`,`C_galioja_iki`) 
    VALUES 
    ("SUT-1l37ptP0","V34-89Hu6r","B3970930","Nullam","2017-07-27 18:18:40"),
    ("SUT-0t63nXf7","N56-49RD4N","B8567791","nascetur","2017-06-08 11:34:31"),
    ("SUT-0e35epl7","h33-50vu0f","B7172629","Sed","2017-11-20 12:53:56"),
    ("SUT-1c60YaB6","v78-61zv2u","B8567791","malesuada","2018-01-27 18:45:48"),
    ("SUT-1e72nnN3","I16-43XC9i","B8765431","sollicitudin","2017-06-25 19:01:41"),
    ("SUT-0T31rXT1","c58-46xD5z","B8567791","metus.","2018-08-31 13:23:20"),
    ("SUT-1m97rKu4","q68-22iw8t","B7172629","at","2018-11-01 05:15:59"),
    ("SUT-1m53BNT1","M96-32xJ6Q","B2925990","orci","2017-07-15 21:26:58"),
    ("SUT-1I73kvU8","f00-78de0t","B0725744","cubilia","2017-01-18 16:30:28"),
    ("SUT-6v14dqm2","J16-95ZE1w","B8765431","mauris","2018-03-17 21:38:36");
INSERT INTO `T_tiekeju_sutartys` (`C_numeris`,`C_numeris_tiekejo`,`T_darbuotojai_C_id`,`C_sutarties_objektas`,`C_galioja_iki`) 
    VALUES 
    ("SUT-3o01uTx4","p24-80ix6G","B2450378","elementum,","2018-10-13 22:40:43"),
    ("SUT-8T53UyG6","i21-63DN5L","B5576178","vel,","2017-09-03 17:43:28"),
    ("SUT-5u22AWZ0","h98-79Er1w","B7172629","Sed","2017-09-22 02:04:51"),
    ("SUT-8D95EfG7","u98-74xM7d","B3088903","lobortis","2018-09-28 22:01:38"),
    ("SUT-4X19JxH5","F42-73qq4l","B9177089","dolor","2017-01-20 04:50:44"),
    ("SUT-1W20IZF2","l49-62LO9A","B1507421","sagittis","2018-10-18 23:43:50"),
    ("SUT-5D89TSh2","h37-95Gd7O","B8984167","Quisque","2017-06-06 20:25:51"),
    ("SUT-9H69kQc7","D75-61SP5V","B8744528","euismod","2018-06-14 04:42:19"),
    ("SUT-9j02dlT4","y95-08fU4M","B4547434","magnis","2018-06-19 03:37:28"),
    ("SUT-5u64TEn9","y03-82dQ4k","B0577052","massa","2016-12-29 15:27:19");
INSERT INTO `T_tiekeju_sutartys` (`C_numeris`,`C_numeris_tiekejo`,`T_darbuotojai_C_id`,`C_sutarties_objektas`,`C_galioja_iki`) 
    VALUES 
    ("SUT-9M78OmA9","n23-28op8O","B6274553","neque.","2018-06-09 14:47:17"),
    ("SUT-5Y11jth0","w74-96Xq3a","B4764221","et","2018-07-15 05:17:27"),
    ("SUT-8O74mgf6","D01-41sm1S","B5162281","commodo","2017-01-05 21:33:16"),
    ("SUT-8a64tZa8","j02-24Il0c","B8712256","faucibus","2018-06-16 17:17:22"),
    ("SUT-6K06xTj5","n92-16ze9t","B3970930","Ut","2018-06-08 04:49:42"),
    ("SUT-4f70Lcq5","s64-32vZ0C","B8712256","erat.","2017-09-20 03:29:56"),
    ("SUT-8Z93BCB4","f73-05aU2k","B1593485","tellus.","2017-09-30 15:03:12"),
    ("SUT-5w74ESH8","r26-31HZ5R","B5603436","enim.","2017-08-04 09:58:33"),
    ("SUT-5s81Gts7","p96-43fd4X","B9575676","sem,","2017-06-01 19:33:03"),
    ("SUT-9e90QRM3","c62-27zI5Y","B8567791","gravida","2017-05-07 14:44:21");



## T_sut_salys

INSERT INTO `T_sut_salys` (`C_sut_nr`,`C_el_p`,`C_vardas`,`C_pavarde`,`C_tel_nr`,`C_adresas`) 
    VALUES 
    ("SUT-4a70Epl0","auctor.ullamcorper.nisl@FuscemollisDuis.edu","Maile","Maddox","+37069048897","9481 Erat St."),
    ("SUT-5w74ESH8","consectetuer.cursus@montesnascetur.edu","Urielle","King","+37064796391","3872 Nibh Rd."),
    ("SUT-9e90QRM3","Phasellus@iaculis.com","Mary","Sloan","+37067055121","P.O. Box 745, 774 Facilisis, Av."),
    ("SUT-2i19yfz0","Donec.at.arcu@ornaretortor.co.uk","Stephanie","Kline","+37066073341","160-6847 Urna. Rd."),
    ("SUT-9j02dlT4","sociis.natoque@sitametornare.net","Alec","Horton","+37068001999","Ap #867-9274 Pede. Rd."),
    ("SUT-9i85SrJ2","tristique.neque.venenatis@uterosnon.edu","Grady","Byrd","+37066363885","Ap #340-8865 Aliquam St."),
    ("SUT-9M78OmA9","metus.Aliquam.erat@sociisnatoquepenatibus.net","Kamal","Moreno","+37066933933","328-3641 Mauris. Street"),
    ("SUT-0e35epl7","velit@Aliquam.ca","Judith","Wolfe","+37065595711","Ap #208-4118 Nunc Street"),
    ("SUT-7Y15gZG5","Morbi.vehicula.Pellentesque@nullaatsem.net","Abra","Ewing","+37066795492","P.O. Box 294, 6997 Ridiculus Avenue"),
    ("SUT-4g98KbG7","ante@seddolor.ca","Kelly","Wilkinson","+37061037897","290-8323 Arcu. Street");
INSERT INTO `T_sut_salys` (`C_sut_nr`,`C_el_p`,`C_vardas`,`C_pavarde`,`C_tel_nr`,`C_adresas`) 
    VALUES 
    ("SUT-7e83EyL9","sem.Nulla@turpisnecmauris.com","Martena","Tate","+37064706184","2637 Tellus. Road"),
    ("SUT-1u33kMu0","sit.amet@Fuscealiquamenim.edu","Hashim","Acosta","+37063337571","1475 Mauris Rd."),
    ("SUT-3l76Pnl7","turpis.non@malesuadafames.co.uk","Rae","Kidd","+37065610855","341-836 Non, Rd."),
    ("SUT-4X19JxH5","mauris@tincidunt.edu","Vladimir","Garrison","+37065371126","P.O. Box 313, 444 Faucibus. Rd."),
    ("SUT-1l37ptP0","interdum@nunc.org","Sean","Yang","+37062699807","549-5282 Mauris Rd."),
    ("SUT-1m53BNT1","posuere.cubilia@nonquamPellentesque.com","Ethan","Herman","+37061175592","P.O. Box 761, 4033 Ornare St."),
    ("SUT-8a64tZa8","Duis@Nunc.net","Moses","Dyer","+37062439969","P.O. Box 246, 1872 Risus. Rd."),
    ("SUT-8x32RoK1","aliquam.adipiscing@ipsum.ca","Arden","Carver","+37066353014","703-4900 Tellus St."),
    ("SUT-8H21wYZ9","at@commodoat.com","Regan","Mcdowell","+37062529055","P.O. Box 311, 7581 Non, Street"),
    ("SUT-2w65MgJ3","Nulla@etarcuimperdiet.edu","Leila","Manning","+37062520696","P.O. Box 577, 9026 Donec Rd.");
INSERT INTO `T_sut_salys` (`C_sut_nr`,`C_el_p`,`C_vardas`,`C_pavarde`,`C_tel_nr`,`C_adresas`) 
    VALUES 
    ("SUT-0j52gmB8","Nunc.commodo@suscipit.ca","Felix","Wynn","+37061996853","698-1529 Enim Street"),
    ("SUT-5u22AWZ0","nec.tempus@etultricesposuere.net","Willow","Farley","+37063478384","789-2358 Libero Road"),
    ("SUT-6Z49tJQ0","Donec@estmollis.net","Pascale","Collins","+37064569733","3916 Aliquam St."),
    ("SUT-5Y11jth0","est.vitae@elementumat.edu","Sierra","Chavez","+37066758296","425-210 Aliquam St."),
    ("SUT-9n48GyU0","Mauris.vel@anequeNullam.edu","Armand","Cervantes","+37064734382","339 Tempus Ave"),
    ("SUT-3t31Wwu9","in.dolor.Fusce@necimperdietnec.co.uk","Mufutau","Curtis","+37066883506","P.O. Box 813, 3375 Taciti Avenue"),
    ("SUT-8C24aRm0","vulputate.nisi.sem@lorem.ca","Cole","Lucas","+37060132766","2570 Nec Rd."),
    ("SUT-8H21wYZ9","neque.In.ornare@Sedpharetrafelis.com","Margaret","Case","+37060026442","Ap #650-4779 Pellentesque Av."),
    ("SUT-9r17DEP6","nibh.sit.amet@augueeu.net","Russell","Ryan","+37069494441","8665 In Street"),
    ("SUT-2i19yfz0","tempor.bibendum@Praesentluctus.co.uk","Nicole","Fulton","+37063791435","Ap #465-5897 Aenean Street");
INSERT INTO `T_sut_salys` (`C_sut_nr`,`C_el_p`,`C_vardas`,`C_pavarde`,`C_tel_nr`,`C_adresas`) 
    VALUES 
    ("SUT-0e35epl7","ipsum@torquentperconubia.com","May","David","+37069147929","P.O. Box 413, 7176 Ullamcorper. Rd."),
    ("SUT-1m97rKu4","metus.urna.convallis@semvitaealiquam.edu","Fay","Compton","+37062568287","630-139 Morbi Rd."),
    ("SUT-1l37ptP0","id.ante@ridiculus.edu","Amanda","Duke","+37063790898","P.O. Box 198, 8695 Parturient St."),
    ("SUT-8H21wYZ9","libero@blanditenim.com","Abraham","Benton","+37069533127","880-3153 Dui. Road"),
    ("SUT-5w74ESH8","amet@actellus.net","Alice","Finch","+37060220959","246-9078 Est St."),
    ("SUT-9j56EuK5","sem.egestas.blandit@nibh.co.uk","Tanisha","Santana","+37067563016","6872 Eget, Ave"),
    ("SUT-8O74mgf6","diam@purus.edu","Ima","Frederick","+37065951159","9221 Risus, Road"),
    ("SUT-4l27rwX2","Suspendisse@amet.org","Rylee","Cole","+37068102928","292-2776 Feugiat. Av."),
    ("SUT-8Z93BCB4","semper@accumsanlaoreetipsum.co.uk","Destiny","Wyatt","+37068967959","P.O. Box 207, 2973 Est, St."),
    ("SUT-2i19yfz0","dolor@adipiscingfringillaporttitor.org","Xantha","Harrington","+37065977848","P.O. Box 686, 1478 Et Ave");
INSERT INTO `T_sut_salys` (`C_sut_nr`,`C_el_p`,`C_vardas`,`C_pavarde`,`C_tel_nr`,`C_adresas`) 
    VALUES 
    ("SUT-3S94OLf4","ligula.Aenean.gravida@aliquetProin.ca","Ethan","Rowland","+37060419412","Ap #710-648 Phasellus Avenue"),
    ("SUT-2P99tJH4","sed@sollicitudinadipiscing.edu","Clementine","Mcmahon","+37064552207","Ap #216-243 Etiam Av."),
    ("SUT-3S94OLf4","magna.et@primisinfaucibus.co.uk","Edward","Mayo","+37062457324","1577 Eu Avenue"),
    ("SUT-8Z93BCB4","dapibus.rutrum@aenim.edu","Deirdre","Strong","+37068871878","P.O. Box 795, 3526 Eros. Av."),
    ("SUT-5u64TEn9","Vivamus.sit.amet@tinciduntcongue.com","Eagan","Avila","+37060979411","131-6415 Ac Avenue"),
    ("SUT-0e35epl7","non@vitaepurusgravida.edu","Callum","Cherry","+37062587950","Ap #936-5766 Maecenas Avenue"),
    ("SUT-9e90QRM3","ligula.Nullam@ullamcorpervelit.edu","Sopoline","Matthews","+37065925144","9596 Lobortis St."),
    ("SUT-8H21wYZ9","dolor@orcisem.net","Justine","Olson","+37062843461","P.O. Box 644, 8472 Neque. Av."),
    ("SUT-8a64tZa8","et.magna@molestiearcuSed.co.uk","Reuben","Hurst","+37069828527","P.O. Box 918, 4398 Non, Street"),
    ("SUT-0j52gmB8","quam.vel@suscipit.ca","Buckminster","Reed","+37067796186","6531 Suspendisse St.");
INSERT INTO `T_sut_salys` (`C_sut_nr`,`C_el_p`,`C_vardas`,`C_pavarde`,`C_tel_nr`,`C_adresas`) 
    VALUES 
    ("SUT-9A56AdF3","Donec.consectetuer@euarcu.co.uk","Stephen","Dyer","+37062108741","P.O. Box 683, 8907 Nulla St."),
    ("SUT-8o15XOP8","cursus@malesuada.edu","Jermaine","Dennis","+37061340451","Ap #680-9233 Dolor Street"),
    ("SUT-7F98hbD2","velit.justo@musProin.ca","Angelica","Huber","+37066561285","8693 Risus. St."),
    ("SUT-4g98KbG7","justo@nisiMauris.com","Roary","Norman","+37067638558","Ap #148-3995 Eu Rd."),
    ("SUT-2w65MgJ3","sed@libero.net","Megan","Espinoza","+37065112240","8858 In, St."),
    ("SUT-6Q16uAa6","egestas.a.dui@Aeneanegetmagna.com","Kevin","Adkins","+37067356283","6346 Sed Ave"),
    ("SUT-5u22AWZ0","ornare.Fusce@Maecenasornareegestas.com","Jacqueline","Mooney","+37066273700","P.O. Box 994, 9547 Venenatis Street"),
    ("SUT-6s17CdZ1","est.ac.mattis@atfringilla.ca","Allegra","Mclaughlin","+37066806516","670-4816 Vitae St."),
    ("SUT-8H21wYZ9","mauris.eu@cursusa.co.uk","Fulton","Walter","+37064932592","Ap #703-7269 Lobortis Street"),
    ("SUT-6s17CdZ1","magnis.dis@malesuadautsem.net","Armand","Leblanc","+37066968570","P.O. Box 788, 3628 Luctus Ave");
INSERT INTO `T_sut_salys` (`C_sut_nr`,`C_el_p`,`C_vardas`,`C_pavarde`,`C_tel_nr`,`C_adresas`) 
    VALUES 
    ("SUT-7Y15gZG5","dolor.nonummy@fermentum.net","Fay","Sloan","+37061752817","Ap #725-7638 Arcu. Rd."),
    ("SUT-1e72nnN3","tellus@fermentumconvallis.edu","Sharon","Bullock","+37063671077","821-9676 Felis. Ave"),
    ("SUT-1m53BNT1","Cum.sociis.natoque@amet.edu","Idona","Estes","+37063223053","Ap #808-4304 Adipiscing, Rd."),
    ("SUT-2w65MgJ3","amet.consectetuer@faucibusleo.org","Zachary","Solis","+37068246742","6707 Et Avenue"),
    ("SUT-2w65MgJ3","tempus.lorem.fringilla@Phaselluslibero.net","Urielle","Parrish","+37068100952","P.O. Box 328, 261 Vel St."),
    ("SUT-4X19JxH5","elit@volutpat.com","Nicholas","Hobbs","+37069760852","8043 Et, Street"),
    ("SUT-7F98hbD2","erat@In.org","Barbara","Michael","+37061257367","Ap #713-3762 In, Rd."),
    ("SUT-9H69kQc7","neque.Nullam.ut@sociis.co.uk","Evelyn","Tucker","+37068279699","501-6762 Mus. Avenue"),
    ("SUT-0t63nXf7","sed.sapien.Nunc@ullamcorpervelitin.org","Lane","Fields","+37061832233","P.O. Box 984, 3363 Sed St."),
    ("SUT-8E99LgE2","est@lacus.net","Selma","Slater","+37067242647","3281 Sed Rd.");
INSERT INTO `T_sut_salys` (`C_sut_nr`,`C_el_p`,`C_vardas`,`C_pavarde`,`C_tel_nr`,`C_adresas`) 
    VALUES 
    ("SUT-7I73TGW2","mollis.non@miloremvehicula.com","Castor","Benson","+37061182829","6621 Scelerisque Road"),
    ("SUT-0j52gmB8","lorem@loremfringillaornare.edu","Ezekiel","Gallegos","+37068606820","Ap #219-4951 Mattis Rd."),
    ("SUT-3l76Pnl7","Cras.dolor.dolor@egetmassa.ca","Alec","Beck","+37064871394","P.O. Box 806, 5630 Vel, Rd."),
    ("SUT-9e90QRM3","sapien.Nunc@eu.com","Gwendolyn","Maxwell","+37062035399","630-7456 Donec Road"),
    ("SUT-3H68uxr8","et.euismod.et@vulputatelacusCras.edu","Mark","James","+37066012840","4083 Eu Av."),
    ("SUT-8H21wYZ9","ut.ipsum@dictumeleifendnunc.co.uk","Aidan","Hutchinson","+37065159650","P.O. Box 128, 2066 Tristique Street"),
    ("SUT-8T53UyG6","eget.nisi@litora.org","Felix","Carney","+37067128788","P.O. Box 429, 6520 Nam Rd."),
    ("SUT-3l76Pnl7","lacus@Donecfeugiat.co.uk","Dorian","Shepard","+37066089527","P.O. Box 654, 1427 Sed, Street"),
    ("SUT-4X19JxH5","Vestibulum@Sed.com","Aquila","Fields","+37068371274","P.O. Box 224, 3441 Sit Ave"),
    ("SUT-1u33kMu0","id@duilectusrutrum.ca","Matthew","Carroll","+37066469642","535-6847 Commodo Av.");
INSERT INTO `T_sut_salys` (`C_sut_nr`,`C_el_p`,`C_vardas`,`C_pavarde`,`C_tel_nr`,`C_adresas`) 
    VALUES 
    ("SUT-2w65MgJ3","ac.metus@porttitorvulputateposuere.co.uk","Chase","Harrington","+37065844293","742-7000 Proin Avenue"),
    ("SUT-3k42WNu5","volutpat@etrisus.com","Fay","Rocha","+37068387249","446 Velit Rd."),
    ("SUT-6Q16uAa6","egestas@magnisdis.co.uk","Gregory","Fields","+37060751989","449-834 Nulla Street"),
    ("SUT-8x32RoK1","Integer@utmi.com","Moana","Petty","+37067387219","4335 Sollicitudin St."),
    ("SUT-8a64tZa8","Lorem.ipsum.dolor@Phasellusliberomauris.ca","Irene","Ingram","+37062358655","Ap #215-4612 Ultricies Ave"),
    ("SUT-5s81Gts7","at.egestas.a@egetlacusMauris.org","George","Downs","+37069051148","215-3685 Sit Avenue"),
    ("SUT-3m99tnQ0","mi@cursus.com","Ulla","Rosario","+37060378964","Ap #668-8812 Aliquam Rd."),
    ("SUT-5h73CYN0","nec.quam@idsapien.edu","Imani","Holmes","+37065017909","688-3000 Non St."),
    ("SUT-0e35epl7","risus@Proinvel.ca","Aubrey","Bright","+37069071041","Ap #213-5040 A Av."),
    ("SUT-6s85MAF5","lorem.Donec@Sedeu.org","Ruth","Baldwin","+37061074822","797-6953 Odio Rd.");









## T_inventorius

INSERT INTO `T_inventorius` (`C_inv_num`,`T_tiekeju_sutartys_C_numeris`,`T_padaliniai_C_padalinio_id`,`T_darbuotojai_C_id`,`C_tipas`) 
    VALUES 
    ("INU-sQ668gM9Bl03","SUT-1m97rKu4","NMD15SHW7CP","B8984167","+37065080159"),
    ("INI-VF836Lp4go66","SUT-8T53UyG6","SBE67MUQ6EK","B3977718","+37062998239"),
    ("INA-Rl921AE8Yv08","SUT-5u22AWZ0","NMD15SHW7CP","B3407194","+37060336937"),
    ("INU-ZT361Bi6qj84","SUT-5u64TEn9","MXQ94MZF5SN","B6877032","+37062503464"),
    ("INU-ZO123NL7hl13","SUT-4X19JxH5","GPR82KVK9TW","B2747082","+37066888827"),
    ("INA-Rv208Gf3Vl84","SUT-5u22AWZ0","IQD25GMN9JZ","B0353604","+37065348576"),
    ("INA-pc881Vz7BV82","SUT-9M78OmA9","IQD25GMN9JZ","B0353604","+37067504006"),
    ("INE-wh188uT9pT15","SUT-5u22AWZ0","NEJ80CDF1KV","B8839135","+37068327733"),
    ("INI-Za017fP9TZ15","SUT-9e90QRM3","UNZ73KVU7IH","B5806048","+37061028224"),
    ("INO-Vq149ru8GH53","SUT-8T53UyG6","XCK12BRT9BS","B8744528","+37067826643");
INSERT INTO `T_inventorius` (`C_inv_num`,`T_tiekeju_sutartys_C_numeris`,`T_padaliniai_C_padalinio_id`,`T_darbuotojai_C_id`,`C_tipas`) 
    VALUES 
    ("INE-ut667yE0Xs11","SUT-8T53UyG6","DVR10CON8KW","B5801386","+37060667921"),
    ("INE-Vo116Kk7ol95","SUT-8T53UyG6","KIZ57NVW8IB","B1623777","+37067625237"),
    ("INI-lR224JW6dh95","SUT-8a64tZa8","OEF87CQF9OB","B3330735","+37066035041"),
    ("INE-FH076Ik1BZ30","SUT-0t63nXf7","SKK43RIN4CQ","B5982162","+37066237323"),
    ("INU-TS477Xe6Nl59","SUT-8T53UyG6","LGR67CSS9EC","B3419767","+37062857549"),
    ("INE-kZ492hv2Pp18","SUT-8Z93BCB4","NEJ80CDF1KV","B9926201","+37065464141"),
    ("INO-vU954mJ8QE41","SUT-1c60YaB6","XCK12BRT9BS","B2747082","+37064960449"),
    ("INA-ND136Pe5xL02","SUT-1c60YaB6","NMD15SHW7CP","B4141624","+37069340129"),
    ("INI-jg692Wm7wT59","SUT-3o01uTx4","MQS01JQW4SN","B1727627","+37067600960"),
    ("INO-jg828Oi8fX04","SUT-1l37ptP0","YOZ57VDR1NQ","B2450378","+37069672927");
INSERT INTO `T_inventorius` (`C_inv_num`,`T_tiekeju_sutartys_C_numeris`,`T_padaliniai_C_padalinio_id`,`T_darbuotojai_C_id`,`C_tipas`) 
    VALUES 
    ("INE-pl374la7dY59","SUT-5u64TEn9","NMD15SHW7CP","B9177089","+37069890032"),
    ("INU-LK487uh1Xw63","SUT-3o01uTx4","NWC75KHV5YW","B0163638","+37062868299"),
    ("INI-LZ308qs1FD01","SUT-8D95EfG7","JLL01QAI8KO","B0743523","+37063544705"),
    ("INA-br796rC7mQ29","SUT-5Y11jth0","DVR10CON8KW","B8567791","+37068758496"),
    ("INU-Km571pP3Ox09","SUT-6K06xTj5","GPR82KVK9TW","B8839135","+37066072129"),
    ("INE-ay202HK2Mk85","SUT-5u64TEn9","RNL66KBW8BT","B4141624","+37060938228"),
    ("INU-PR581Ng1KS49","SUT-8D95EfG7","UNZ73KVU7IH","B6744220","+37061551544"),
    ("INE-mO654Dv4xr16","SUT-5D89TSh2","GPR82KVK9TW","B2297146","+37061545027"),
    ("INO-TD664Tl8As54","SUT-8D95EfG7","OEF87CQF9OB","B3056716","+37069904085"),
    ("INU-GM682qH9mC99","SUT-1l37ptP0","SBE67MUQ6EK","B0353604","+37066135610");
INSERT INTO `T_inventorius` (`C_inv_num`,`T_tiekeju_sutartys_C_numeris`,`T_padaliniai_C_padalinio_id`,`T_darbuotojai_C_id`,`C_tipas`) 
    VALUES 
    ("INO-oE063FW9AB90","SUT-5u64TEn9","ZLC61GYV9CS","B3814295","+37068903752"),
    ("INI-rY784PZ5Bj86","SUT-0T31rXT1","LGR67CSS9EC","B3970930","+37064260934"),
    ("INO-aX544Zg6wg79","SUT-8Z93BCB4","RIG54WTQ6ZR","B5019924","+37060956027"),
    ("INO-KV296pU9LQ08","SUT-1m53BNT1","HWD45SFO2DD","B8952892","+37062795991"),
    ("INI-ok518Nf2Wm26","SUT-9e90QRM3","IQD25GMN9JZ","B0013156","+37065422482"),
    ("INE-DU765MK5pN53","SUT-5Y11jth0","HXX73FII0CJ","B4764221","+37069412978"),
    ("INO-bM623MP5CW17","SUT-3o01uTx4","HWD45SFO2DD","B7111325","+37068362286"),
    ("INE-iS458XN0hb80","SUT-0T31rXT1","DVR10CON8KW","B2614557","+37066426362"),
    ("INA-eS248Pc2zR13","SUT-5u64TEn9","STS02VJG6QK","B5603436","+37068083003"),
    ("INU-os262iQ9SX32","SUT-0T31rXT1","AJY33MTZ1YO","B2925990","+37068710245");
INSERT INTO `T_inventorius` (`C_inv_num`,`T_tiekeju_sutartys_C_numeris`,`T_padaliniai_C_padalinio_id`,`T_darbuotojai_C_id`,`C_tipas`) 
    VALUES 
    ("INA-dB329TZ5JR59","SUT-9H69kQc7","XCK12BRT9BS","B5358597","+37065073927"),
    ("INI-gR040uT1lg42","SUT-5u64TEn9","MQS01JQW4SN","B3088903","+37069356579"),
    ("INO-jg461dL7Ka28","SUT-0e35epl7","RKU81ZOM2AL","B9726734","+37061092210"),
    ("INE-ed766JA7CD17","SUT-1l37ptP0","LDI04VGV5UC","B3056716","+37062696979"),
    ("INI-XJ127pH0eA20","SUT-8T53UyG6","XCK12BRT9BS","B5982162","+37069329702"),
    ("INI-ST944Ls7lU86","SUT-5w74ESH8","YJO44QTK6RI","B9536827","+37060348712"),
    ("INE-bw809eb0mA17","SUT-9H69kQc7","FQG84NIO6TW","B8567791","+37062771680"),
    ("INO-IY050fR7iF06","SUT-1m53BNT1","DEU13ZZD2EV","B9633722","+37061094536"),
    ("INO-om981Ow7mJ71","SUT-9j02dlT4","VRE42EEQ8JV","B1315419","+37063545631"),
    ("INO-eP020ij1SC64","SUT-5u64TEn9","IHP70CXW4CT","B5925343","+37069676590");
INSERT INTO `T_inventorius` (`C_inv_num`,`T_tiekeju_sutartys_C_numeris`,`T_padaliniai_C_padalinio_id`,`T_darbuotojai_C_id`,`C_tipas`) 
    VALUES 
    ("INA-IO178pk0iv17","SUT-4X19JxH5","IAX31DKF8US","B5576178","+37063278393"),
    ("INI-CZ948sW6MH69","SUT-1l37ptP0","GPR82KVK9TW","B9402458","+37063904335"),
    ("INO-aY736Mp8Tu58","SUT-5u64TEn9","AJY33MTZ1YO","B3408913","+37066811872"),
    ("INO-aW180yj1PW98","SUT-0T31rXT1","AJY33MTZ1YO","B7172629","+37061426221"),
    ("INI-KC055DP6OX86","SUT-4X19JxH5","RPV61OXO0OG","B5019924","+37060491637"),
    ("INI-TZ873qe3rw24","SUT-8T53UyG6","HNT42NUP7LN","B3419767","+37064556978"),
    ("INE-UX224gC8Ul85","SUT-8T53UyG6","HXX73FII0CJ","B5806048","+37066151731"),
    ("INU-DB177tB9gU00","SUT-5u64TEn9","ZWW89SHX8CT","B0013156","+37068553318"),
    ("INI-qo754yW9fo01","SUT-4X19JxH5","IQD25GMN9JZ","B5806048","+37068500422"),
    ("INA-dG799pC9uF67","SUT-6K06xTj5","BTP68ODG0CN","B1451326","+37064636392");
INSERT INTO `T_inventorius` (`C_inv_num`,`T_tiekeju_sutartys_C_numeris`,`T_padaliniai_C_padalinio_id`,`T_darbuotojai_C_id`,`C_tipas`) 
    VALUES 
    ("INU-du557qd1rM02","SUT-6K06xTj5","DEU13ZZD2EV","B3814295","+37069082805"),
    ("INE-yE306Je6mQ79","SUT-9H69kQc7","MVG31GID3HK","B8567791","+37065085680"),
    ("INE-zj014Zj2wR47","SUT-1m97rKu4","LGR67CSS9EC","B3566002","+37068442096"),
    ("INA-Kh238tN7Wg17","SUT-0e35epl7","HNT42NUP7LN","B0063069","+37066271217"),
    ("INA-Sf370hM9Ba55","SUT-3o01uTx4","XWH96ELU9DW","B8165418","+37069722373"),
    ("INA-TW121ab7cs28","SUT-9H69kQc7","KKU08WRW7LE","B8984167","+37066321484"),
    ("INA-UY563JF1qt04","SUT-4f70Lcq5","FQD90PJT0JO","B2409781","+37061324011"),
    ("INU-Gn737Uf6Es99","SUT-5u64TEn9","LGR67CSS9EC","B3419767","+37066095714"),
    ("INI-Ae360fo8tw17","SUT-1m53BNT1","CSB94WDI8GG","B5982162","+37063312902"),
    ("INU-LD585yF0vK97","SUT-5D89TSh2","AJY33MTZ1YO","B1507421","+37065468502");
INSERT INTO `T_inventorius` (`C_inv_num`,`T_tiekeju_sutartys_C_numeris`,`T_padaliniai_C_padalinio_id`,`T_darbuotojai_C_id`,`C_tipas`) 
    VALUES 
    ("INA-GG270jO3Ew71","SUT-1l37ptP0","LAF77LQQ2AD","B9402458","+37063251894"),
    ("INI-XC243Ch6bL23","SUT-5u64TEn9","CSB94WDI8GG","B6876710","+37069038368"),
    ("INI-dZ247Dg0GP70","SUT-1W20IZF2","NGQ71LFJ2WO","B6877032","+37066626788"),
    ("INE-AX776FF9yj81","SUT-5Y11jth0","NMD15SHW7CP","B5801386","+37065156946"),
    ("INO-BI170qF4Dy45","SUT-8T53UyG6","ILI96COS0CI","B6244412","+37064734151"),
    ("INE-kD014qZ7RK78","SUT-1c60YaB6","XCK12BRT9BS","B3667647","+37069764463"),
    ("INO-GU304ON1nM54","SUT-8Z93BCB4","RMH93WYU5HZ","B3566002","+37064373056"),
    ("INE-Bl426Dh9bw71","SUT-5u64TEn9","ILI96COS0CI","B2614557","+37060905284"),
    ("INO-Yp156kZ1JX01","SUT-8T53UyG6","PEQ97AKQ2TX","B7172629","+37063097293"),
    ("INU-nw534cj5oA99","SUT-9H69kQc7","NXA21FZR1DY","B0470785","+37063666118");
INSERT INTO `T_inventorius` (`C_inv_num`,`T_tiekeju_sutartys_C_numeris`,`T_padaliniai_C_padalinio_id`,`T_darbuotojai_C_id`,`C_tipas`) 
    VALUES 
    ("INE-LS533JV8iI67","SUT-9j02dlT4","GHR82WMZ3JG","B8165418","+37060438239"),
    ("INU-rR355JO9Zm93","SUT-1m53BNT1","NEJ80CDF1KV","B3407194","+37065448781"),
    ("INE-Nn204Zl5TJ63","SUT-5u64TEn9","HXX73FII0CJ","B0013156","+37060945646"),
    ("INO-tg148RL1ux64","SUT-5Y11jth0","IQD25GMN9JZ","B6877032","+37060732358"),
    ("INI-wE456bg8lq01","SUT-8D95EfG7","SKK43RIN4CQ","B0577052","+37063218932"),
    ("INA-lq324TI1cR95","SUT-5u64TEn9","MVG31GID3HK","B1512445","+37066891644"),
    ("INE-Dp514Gu2jt73","SUT-8T53UyG6","ICR17ENQ2TU","B0743523","+37066337239"),
    ("INE-mD116QH3sQ39","SUT-0T31rXT1","GHR82WMZ3JG","B2614557","+37068640784"),
    ("INI-dL646MU8yW60","SUT-5u64TEn9","IQD25GMN9JZ","B2925990","+37065142197"),
    ("INU-bN584nt1AW75","SUT-1W20IZF2","ZLC61GYV9CS","B4297760","+37069444645");










## T_planai

INSERT INTO `T_planai` (`C_pavadinimas`,`C_pradzia`,`C_pabaiga`,`C_komentaras`) 
    VALUES 
    ("velit","2015-06-29 02:25:31","2016-12-25 07:38:09","ullamcorper eu, euismod ac, fermentum vel, mauris. Integer"),
    ("lectus,","2015-11-20 10:17:46","2016-12-28 03:32:51","lorem fringilla"),
    ("placerat","2015-02-28 07:00:14","2016-12-24 00:38:51","Nulla dignissim."),
    ("pharetra.","2015-10-06 11:16:23","2016-12-26 18:11:15","natoque penatibus"),
    ("nunc","2015-08-30 18:42:34","2016-12-25 00:17:31","Donec porttitor tellus non magna. Nam ligula elit, pretium et,"),
    ("diam.","2015-11-07 14:13:31","2016-12-28 15:15:54","ut odio vel"),
    ("magna","2015-06-17 08:20:34","2016-12-29 08:30:38","risus quis diam luctus"),
    ("mi","2015-04-24 09:53:35","2016-12-23 08:32:58","id, erat. Etiam vestibulum massa rutrum magna."),
    ("porttitor","2015-04-09 06:46:06","2016-12-25 09:01:33","vitae risus. Duis"),
    ("massa.","2015-06-14 12:16:58","2016-12-29 04:23:07","ac risus. Morbi metus. Vivamus euismod urna. Nullam lobortis");

INSERT INTO `T_planai` (`C_pavadinimas`,`C_pradzia`,`C_pabaiga`,`C_komentaras`) 
    VALUES 
    ("libero","2015-08-31 03:43:20","2016-12-28 19:58:10","cursus in, hendrerit consectetuer, cursus et, magna."),
    ("posuere","2015-09-23 00:08:43","2016-12-29 04:21:24","iaculis aliquet diam. Sed"),
    ("Donec","2015-09-14 03:24:49","2016-12-29 06:48:51","lorem, sit amet ultricies sem magna nec"),
    ("odio","2015-07-23 06:36:32","2016-12-26 03:25:28","non, lacinia at, iaculis quis, pede. Praesent eu"),
    ("mauris.","2015-02-26 04:26:55","2016-12-26 08:44:12","cursus. Integer"),
    ("est","2015-10-20 22:09:05","2016-12-29 11:39:16","a, facilisis non,"),
    ("eget","2015-08-31 15:19:55","2016-12-26 04:57:21","tempus"),
    ("arcu.","2015-03-20 18:18:24","2016-12-26 00:48:27","odio tristique"),
    ("sem","2015-04-26 04:25:40","2016-12-25 03:39:17","placerat, orci"),
    ("magna.","2015-04-02 23:22:59","2016-12-26 15:30:07","scelerisque neque. Nullam");

INSERT INTO `T_planai` (`C_pavadinimas`,`C_pradzia`,`C_pabaiga`,`C_komentaras`) 
    VALUES 
    ("semper","2015-02-08 22:39:19","2016-12-25 10:17:22","lacinia orci, consectetuer euismod est arcu ac"),
    ("Etiam","2015-10-11 00:40:43","2016-12-26 15:30:27","convallis convallis dolor. Quisque tincidunt pede ac urna. Ut tincidunt"),
    ("neque.","2015-10-09 02:45:30","2016-12-24 13:35:15","mauris erat eget ipsum. Suspendisse sagittis. Nullam vitae diam. Proin"),
    ("pellentesque","2015-06-09 22:35:54","2016-12-22 00:46:12","in, dolor. Fusce feugiat. Lorem ipsum dolor sit"),
    ("sapien,","2015-07-16 20:07:33","2016-12-27 11:12:07","sagittis augue, eu tempor erat neque non quam."),
    ("nulla.","2015-02-10 03:24:55","2016-12-25 23:50:52","pharetra nibh. Aliquam ornare, libero at"),
    ("Sed","2015-10-03 14:30:49","2016-12-23 11:58:25","Fusce diam nunc, ullamcorper eu, euismod"),
    ("leo,","2015-02-23 03:44:04","2016-12-29 11:06:14","ante"),
    ("luctus","2015-10-21 15:32:34","2016-12-24 09:02:16","vitae,"),
    ("quam,","2015-02-17 11:31:54","2016-12-29 01:25:02","Aenean gravida nunc");

INSERT INTO `T_planai` (`C_pavadinimas`,`C_pradzia`,`C_pabaiga`,`C_komentaras`) 
    VALUES 
    ("Phasellus","2015-05-12 22:17:12","2016-12-26 04:04:43","eget ipsum. Suspendisse sagittis. Nullam vitae"),
    ("risus","2015-06-12 09:06:09","2016-12-26 05:16:26","ipsum. Phasellus vitae mauris sit amet"),
    ("urna.","2015-11-07 03:33:15","2016-12-27 21:49:59","nisi magna sed dui."),
    ("ut","2015-09-28 10:48:13","2016-12-26 14:03:03","non massa non ante bibendum ullamcorper. Duis cursus, diam"),
    ("et","2015-11-26 06:16:00","2016-12-24 03:39:08","in consectetuer ipsum nunc id enim. Curabitur massa. Vestibulum accumsan"),
    ("id,","2015-03-07 11:00:21","2016-12-24 21:30:10","sit"),
    ("risus.","2015-02-08 23:09:08","2016-12-28 21:35:09","lectus, a sollicitudin"),
    ("In","2015-01-26 08:42:59","2016-12-23 04:51:06","at arcu. Vestibulum ante ipsum primis in faucibus orci"),
    ("elementum","2015-02-18 02:12:09","2016-12-22 16:33:34","sodales nisi"),
    ("dui.","2015-02-14 02:03:25","2016-12-26 00:51:13","ut mi. Duis risus odio, auctor vitae, aliquet");








## T_klientu_paslaugu_sut

INSERT INTO `T_klientu_paslaugu_sut` (`C_numeris`,`T_darbuotojai_C_id`,`T_padaliniai_C_padalinio_id`,`C_pask_imoka`,`C_pradzia`,`C_pabaiga`) 
	VALUES 
	("SUT-1m97rKu4","B8839135","NEJ80CDF1KV","2016-05-27 21:54:07","2015-06-28 00:13:34","2015-03-25 03:08:06"),
	("SUT-8T53UyG6","B9402458","PXA53IVZ9CV","2015-04-26 14:06:28","2016-07-04 03:23:25","2016-01-24 09:52:57"),
	("SUT-9M78OmA9","B3330735","UYG18ZJN9LD","2015-03-15 08:23:12","2015-12-13 18:49:25","2016-07-18 22:36:57"),
	("SUT-4X19JxH5","B8744528","NEJ80CDF1KV","2016-02-10 06:11:04","2015-08-22 13:33:06","2016-04-03 02:14:05"),
	("SUT-1m53BNT1","B2925990","NXA21FZR1DY","2016-06-09 02:20:46","2016-10-10 06:56:31","2015-11-22 11:07:42"),
	("SUT-9H69kQc7","B2297146","LAF77LQQ2AD","2016-02-22 22:10:36","2016-10-02 04:36:34","2015-02-05 00:11:03"),
	("SUT-5u64TEn9","B4857371","LGR67CSS9EC","2016-12-22 09:39:35","2015-03-07 08:17:25","2015-02-18 08:49:02"),
	("SUT-9j02dlT4","B1727627","MDZ32TTP5EZ","2016-09-01 01:34:19","2016-04-04 08:13:34","2015-03-21 04:07:08"),
	("SUT-6K06xTj5","B3970930","WCQ47CHO9QT","2015-03-07 19:03:14","2016-09-30 16:07:27","2016-07-21 11:35:32"),
	("SUT-0t63nXf7","B6417727","XWH96ELU9DW","2016-06-27 20:45:50","2015-01-01 16:27:38","2016-04-28 13:23:25");

INSERT INTO `T_klientu_paslaugu_sut` (`C_numeris`,`T_darbuotojai_C_id`,`T_padaliniai_C_padalinio_id`,`C_pask_imoka`,`C_pradzia`,`C_pabaiga`) 
	VALUES 
	("SUT-7K09Knh5","B5176063","QNT88OCF4MW","2015-07-19 19:41:04","2016-09-10 08:19:17","2015-03-09 02:59:09"),
	("SUT-8d17fyc1","B4297760","STS02VJG6QK","2015-09-20 21:34:13","2015-02-16 13:07:51","2015-11-16 07:02:28"),
	("SUT-9j56EuK5","B8567791","GPR82KVK9TW","2016-12-08 01:28:16","2015-09-17 11:45:36","2015-08-11 11:12:55"),
	("SUT-5I83mRo5","B8165418","AJY33MTZ1YO","2016-10-28 03:59:32","2016-03-14 20:00:03","2016-09-20 08:23:44"),
	("SUT-6c50zje6","B1315419","LAF77LQQ2AD","2015-03-19 15:15:02","2015-11-02 00:37:36","2016-12-24 07:10:47"),
	("SUT-6v14dqm2","B4440830","UNZ73KVU7IH","2015-03-15 18:21:50","2015-09-29 16:09:48","2016-12-21 03:07:19"),
	("SUT-9U61ONF8","B3667647","MVG31GID3HK","2016-11-07 06:06:02","2015-12-12 00:57:00","2015-03-13 10:33:20"),
	("SUT-8D95EfG7","B6244412","FQG84NIO6TW","2015-01-20 20:26:03","2016-08-21 14:05:37","2016-09-09 08:44:09"),
	("SUT-3J90cEl6","B3056716","PLR27JHY7VR","2016-10-03 12:26:33","2016-11-11 09:52:49","2016-04-26 17:26:10"),
	("SUT-8K20ZkV3","B0577052","AJY33MTZ1YO","2016-07-17 14:52:58","2015-12-08 09:57:23","2015-09-28 15:44:34");

INSERT INTO `T_klientu_paslaugu_sut` (`C_numeris`,`T_darbuotojai_C_id`,`T_padaliniai_C_padalinio_id`,`C_pask_imoka`,`C_pradzia`,`C_pabaiga`) 
	VALUES 
	("SUT-4R63Gaq1","B9029451","XCK12BRT9BS","2015-09-05 05:56:32","2016-02-12 20:20:37","2015-11-02 18:51:48"),
	("SUT-2O61lNb9","B5079411","AJY33MTZ1YO","2015-11-09 04:15:48","2016-06-19 12:29:24","2015-01-06 02:56:44"),
	("SUT-8e35Imj3","B3088903","RNE55NRS7QZ","2015-01-12 21:39:13","2016-09-19 05:37:06","2015-11-27 20:38:05"),
	("SUT-4w17guN3","B2710672","BQS64AHF8YM","2016-04-23 06:17:57","2015-05-05 21:36:48","2015-11-12 14:02:14"),
	("SUT-1Z57Ksr0","B6417727","YCF68ASP3GV","2015-08-25 06:56:59","2015-06-20 16:30:01","2016-12-24 23:26:45"),
	("SUT-0e35epl7","B9926201","UNZ73KVU7IH","2015-08-31 04:30:40","2015-12-27 12:58:34","2016-10-10 05:59:37"),
	("SUT-0B95VsW1","B0013156","RNL66KBW8BT","2016-10-06 17:43:52","2015-12-23 12:41:29","2015-10-21 19:31:44"),
	("SUT-6T52rzN0","B2289768","HNT42NUP7LN","2015-01-31 23:51:05","2015-05-17 23:58:51","2016-12-25 02:12:08"),
	("SUT-8x32RoK1","B1315419","VXM24FPO5RS","2016-07-16 13:49:07","2016-03-28 18:15:04","2015-11-05 22:12:53"),
	("SUT-0u19yvG8","B3814295","YJO44QTK6RI","2016-01-09 08:32:44","2015-08-25 17:19:19","2015-06-21 13:11:58");

INSERT INTO `T_klientu_paslaugu_sut` (`C_numeris`,`T_darbuotojai_C_id`,`T_padaliniai_C_padalinio_id`,`C_pask_imoka`,`C_pradzia`,`C_pabaiga`) 
	VALUES 
	("SUT-2L55NxL9","B0577052","GNN37PVP2ZS","2015-12-03 05:20:48","2016-02-03 07:40:19","2015-03-09 12:38:10"),
	("SUT-6v60Lme8","B5711309","EPT81ZVX8BN","2016-08-08 04:50:39","2016-05-20 14:47:06","2015-09-22 03:06:01"),
	("SUT-5E21ztP7","B5603436","PLR27JHY7VR","2016-07-31 23:36:05","2016-05-08 01:51:10","2015-10-06 15:57:06"),
	("SUT-5D89TSh2","B3408913","NEJ80CDF1KV","2015-05-11 06:22:12","2015-01-16 22:06:08","2016-04-10 07:46:25"),
	("SUT-2S22IDx1","B0013156","HXJ08CMF2LI","2015-02-18 03:40:17","2016-07-11 10:15:47","2016-01-02 10:47:42"),
	("SUT-1x09Zcx6","B0063069","KIZ57NVW8IB","2016-08-13 02:07:09","2016-10-04 14:24:26","2016-01-21 08:11:49"),
	("SUT-5j66CIW5","B1623777","LAF77LQQ2AD","2015-05-02 06:33:11","2016-08-21 08:22:04","2015-06-04 09:34:44"),
	("SUT-2k12toI6","B4928546","HKC70SLW3MF","2015-10-18 02:51:56","2016-02-10 06:54:31","2015-08-24 18:31:01"),
	("SUT-9x35Ryv7","B9177089","AJY33MTZ1YO","2015-11-02 23:17:44","2015-12-26 20:01:09","2015-11-04 11:52:03"),
	("SUT-7N78bwB8","B1507421","IAX31DKF8US","2016-02-25 11:07:40","2015-11-23 18:05:47","2015-02-18 20:21:30");

INSERT INTO `T_klientu_paslaugu_sut` (`C_numeris`,`T_darbuotojai_C_id`,`T_padaliniai_C_padalinio_id`,`C_pask_imoka`,`C_pradzia`,`C_pabaiga`) 
	VALUES 
	("SUT-9V10mnE6","B3088903","JLL01QAI8KO","2016-07-01 07:50:32","2016-10-08 03:45:50","2015-06-06 15:36:07"),
	("SUT-9n48GyU0","B0743523","ILW09HGY8BS","2016-11-02 03:28:36","2015-04-18 13:44:40","2016-10-05 20:57:10"),
	("SUT-5U05KMq2","B0013156","QVC68AHH0QV","2015-04-09 01:44:47","2016-09-01 11:32:50","2015-09-03 16:06:15"),
	("SUT-2i19yfz0","B2409781","UNZ73KVU7IH","2016-09-06 03:28:53","2015-01-09 01:24:16","2015-05-29 03:27:43"),
	("SUT-0L70LkV2","B0353604","AJY33MTZ1YO","2015-03-02 03:42:46","2015-08-24 06:04:08","2016-07-16 02:55:22"),
	("SUT-6R38fTV7","B0325529","NXA21FZR1DY","2015-01-09 19:07:04","2016-08-07 13:35:30","2016-10-26 19:22:19"),
	("SUT-1c60YaB6","B3566002","RMH93WYU5HZ","2015-07-22 17:04:44","2016-08-01 02:13:38","2016-01-12 17:48:45"),
	("SUT-1u33kMu0","B4764221","LAF77LQQ2AD","2016-07-22 09:33:05","2016-06-21 08:50:05","2016-04-08 09:15:44"),
	("SUT-6o27cMq7","B8632059","ETP30BZS8PT","2015-12-08 15:49:42","2016-09-15 13:52:18","2016-01-01 08:07:59"),
	("SUT-3P05Kdo7","B6877032","EPT81ZVX8BN","2016-06-27 11:38:28","2015-11-07 01:42:16","2015-09-28 22:18:03");



















