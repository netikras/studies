#include <stdint.h>

/* USAGE:
cout << lookup3(argv[1], strlen(argv[1]),42)<<endl;
*/


uint32_t lookup3 ( const void * key, int length, uint32_t initval );

